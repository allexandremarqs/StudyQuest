import { useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';
import {
  Activity, ArrowLeft, ArrowRight, BookOpen, Check,
  CheckCircle2, ChevronRight, CircleHelp, Clock3, Compass, Download, FileUp,
  Flag, GraduationCap, LayoutDashboard, List, LockKeyhole, Map, Minus, Plus, RotateCcw,
  ShieldAlert, Sparkles, Target, Trophy, Upload, X,
} from 'lucide-react';
import { StudyQuestProvider, useStudyQuest } from '@/state/StudyQuestContext';
import type { ReviewEntry } from '@/state/StudyQuestContext';
import { skills, missions, getSkill } from '@/domain/catalog';
import type { Skill, Mission } from '@/domain/types';
import { canCompleteMission, getLevelProgress } from '@/domain/engine';

type Mode = 'diagnostic' | 'practice' | 'mastery';
type AnyRecord = Record<string, any>;

const navItems = [
  { href: '/', label: 'Visão geral', icon: LayoutDashboard },
  { href: '/trilha', label: 'Trilha', icon: Map },
  { href: '/missoes', label: 'Missões', icon: Flag },
  { href: '/revisoes', label: 'Revisões', icon: RotateCcw },
  { href: '/perfil', label: 'Perfil', icon: GraduationCap },
];

function titleCaseStatus(status: unknown) {
  const s = String(status ?? 'locked').toLowerCase();
  if (['mastered', 'mastery', 'concluida', 'concluída'].includes(s)) return 'Dominada';
  if (s === 'review-due') return 'Revisão pendente';
  if (['learning', 'in_progress', 'in-progress', 'em andamento'].includes(s)) return 'Em aprendizado';
  if (['available', 'unlocked'].includes(s)) return 'Disponível';
  return 'Bloqueada';
}
function isMastered(status: unknown) { return ['Dominada', 'Revisão pendente'].includes(titleCaseStatus(status)); }
function isLocked(status: unknown) { return titleCaseStatus(status) === 'Bloqueada'; }
function niceDate(date?: string) {
  if (!date) return 'Sem data';
  const parsed = new Date(date);
  return Number.isNaN(parsed.getTime()) ? date : parsed.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}
function itemText(item: AnyRecord, keys: string[], fallback = ''): string {
  for (const key of keys) if (typeof item?.[key] === 'string' && item[key].trim()) return item[key];
  return fallback;
}
function getPrereqBlockers(skill: Skill, skillStatus: (id: string) => unknown) {
  return skill.prerequisites.map((id) => getSkill(id)).filter((item): item is Skill => Boolean(item))
    .filter((item) => !isMastered(skillStatus(item.id)));
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { state, storageError, recoverStorage } = useStudyQuest();
  const level = getLevelProgress(state.student.totalXp);
  return <div className="app-shell min-h-[100dvh] text-foreground">
    <aside className="app-sidebar fixed inset-y-0 left-0 z-20 hidden w-[236px] flex-col px-4 py-5 md:flex">
      <Link href="/" className="mb-9 flex items-center gap-3 px-2" data-testid="link-brand">
        <span className="grid h-9 w-9 place-items-center rounded-[10px] border border-violet-300/20 bg-violet-300/10 text-violet-200"><Compass size={19} /></span>
        <span><strong className="font-display text-[17px] tracking-tight text-slate-100">StudyQuest</strong><span className="block text-[10px] font-semibold tracking-[.14em] text-slate-500">JORNADA ACADÊMICA</span></span>
      </Link>
      <p className="eyebrow px-3 pb-2">Seu espaço</p>
      <nav className="space-y-1">
        {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`link-nav-${href.replace('/', '') || 'inicio'}`}><Icon size={17} strokeWidth={1.8} />{label}</Link>)}
      </nav>
      <div className="mt-auto rounded-xl border border-[#2c3040] bg-[#171b26] p-4">
        <div className="mb-3 flex items-center justify-between"><span className="eyebrow">Seu progresso</span><Activity size={15} className="text-violet-300" /></div>
        <div className="flex items-baseline gap-2"><strong className="font-display text-2xl text-slate-100">Nível {level.level}</strong><span className="text-xs text-slate-500">{state.student.totalXp} XP</span></div>
        <div className="mt-3 meter"><span style={{ width: `${level.percentToNextLevel}%` }} /></div>
        <p className="mt-2 text-[11px] text-slate-500">{level.xpForNextLevel - level.xpIntoLevel} XP até o nível {level.level + 1}</p>
      </div>
      <Link href="/objetivo" className="mt-4 flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-slate-500 transition hover:bg-white/5 hover:text-slate-200" data-testid="link-goal-shortcut"><Target size={15} />Objetivo acadêmico</Link>
    </aside>
    <header className="sticky top-0 z-20 flex h-[62px] items-center justify-between border-b border-[#292e3b] bg-[#11141d]/95 px-4 backdrop-blur-xl md:hidden">
      <Link href="/" className="flex items-center gap-2" data-testid="link-brand-mobile"><span className="grid h-8 w-8 place-items-center rounded-lg bg-violet-300/10 text-violet-200"><Compass size={17} /></span><strong className="font-display text-base">StudyQuest</strong></Link>
      <Link href="/perfil" className="grid h-8 w-8 place-items-center rounded-full border border-[#393e4c] bg-[#202430] text-xs font-bold text-violet-100" aria-label="Abrir perfil" data-testid="link-profile-mobile">{state.student.name?.trim()?.slice(0, 1)?.toUpperCase() || 'E'}</Link>
    </header>
    <main className="md:ml-[236px]">
      {storageError && <div className="mx-auto mt-4 flex w-[min(100%-32px,1120px)] flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-800/50 bg-amber-950/20 p-4 text-sm" role="alert"><div className="flex items-start gap-3"><ShieldAlert size={17} className="mt-0.5 shrink-0 text-amber-300" /><div><p className="font-semibold text-amber-100">Não foi possível acessar seu progresso salvo</p><p className="mt-1 text-xs leading-5 text-amber-100/65">{storageError}</p></div></div><button className="action-secondary" onClick={() => { if (window.confirm('A recuperação reinicia o progresso salvo neste dispositivo. Deseja continuar?')) recoverStorage(); }} data-testid="button-recover-storage">Recuperar armazenamento</button></div>}
      {children}
    </main>
    <nav className="mobile-nav md:hidden" aria-label="Navegação principal">
      {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={location === href ? 'active' : ''} data-testid={`mobile-nav-${href.replace('/', '') || 'inicio'}`}><Icon size={18} /><span>{label}</span></Link>)}
    </nav>
  </div>;
}

function PageHeading({ overline, title, description, action }: { overline?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
    <div>{overline && <p className="eyebrow mb-2">{overline}</p>}<h1 className="page-title">{title}</h1>{description && <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">{description}</p>}</div>
    {action}
  </div>;
}
function StatusPill({ status }: { status: unknown }) {
  const text = titleCaseStatus(status);
  const cls = text === 'Dominada' ? 'border-emerald-700/50 bg-emerald-950/40 text-emerald-300' : text === 'Revisão pendente' ? 'border-amber-700/40 bg-amber-950/30 text-amber-200' : text === 'Disponível' || text === 'Em aprendizado' ? 'border-violet-700/40 bg-violet-950/40 text-violet-200' : 'border-slate-700 bg-slate-800/70 text-slate-400';
  return <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide ${cls}`}>{text === 'Dominada' ? <CheckCircle2 size={12} /> : text === 'Bloqueada' ? <LockKeyhole size={11} /> : <Sparkles size={11} />}{text}</span>;
}

function Dashboard() {
  const { state, skillStatus } = useStudyQuest();
  const level = getLevelProgress(state.student.totalXp);
  const mastered = skills.filter((s) => isMastered(skillStatus(s.id)));
  const open = skills.filter((s) => !isLocked(skillStatus(s.id)) && !isMastered(skillStatus(s.id)));
  const progress = skills.length ? Math.round(mastered.length / skills.length * 100) : 0;
  const nextSkill = open[0] || skills.find((s) => !isMastered(skillStatus(s.id)));
  const recent = [...state.activity].slice(0, 5) as unknown as AnyRecord[];
  const pendingReviews = state.reviewSchedule.filter((review) => !review.completedAt);
  const nextReview = [...pendingReviews].sort((a, b) => a.dueAt.localeCompare(b.dueAt))[0];
  const dueReviewCount = pendingReviews.filter((review) => new Date(review.dueAt).getTime() <= Date.now()).length;
  const upcomingMissions = missions.filter((mission) => !state.completedMissions.includes(mission.id)).slice(0, 2);
  const goal = state.goal;
  return <div className="main-content fade-in">
    <PageHeading overline="PAINEL DE JORNADA" title={`Olá, ${state.student.name || 'estudante'}.`} description="Cada conceito dominado abre caminho para o próximo." action={<Link href="/trilha" className="action-secondary" data-testid="button-open-trail"><Map size={15} />Ver trilha <ArrowRight size={14} /></Link>} />
    <section className="panel relative mb-5 overflow-hidden p-5 sm:p-7">
      <div className="absolute -right-8 -top-16 h-60 w-60 rounded-full border border-violet-300/10" /><div className="absolute -right-1 -top-9 h-44 w-44 rounded-full border border-violet-300/10" />
      <div className="relative grid items-center gap-7 md:grid-cols-[1fr_210px]">
         <div><p className="eyebrow mb-3">OBJETIVO ACADÊMICO</p><h2 className="font-display text-[22px] font-semibold tracking-tight text-slate-100">{goal.title || 'Defina seu próximo objetivo'}</h2><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">{goal.description || 'Trilha ilustrativa de conhecimentos prévios para Cálculo I.'}</p><div className="mt-5 flex flex-wrap items-center gap-2 text-xs text-slate-400"><span className="rounded-md border border-[#363b49] bg-[#1d222d] px-2.5 py-1.5">{goal.course || 'Curso não definido'}</span><span className="text-slate-600">/</span><span>{goal.discipline || 'Disciplina não definida'}</span><Link href="/objetivo" className="ml-1 font-semibold text-violet-300 hover:text-violet-200" data-testid="link-edit-goal">Editar objetivo <ChevronRight size={13} className="inline" /></Link></div></div>
        <div className="flex items-center gap-5 md:justify-end"><div className="relative grid h-[116px] w-[116px] shrink-0 place-items-center rounded-full" style={{ background: `conic-gradient(#9a89d6 ${progress}%, #2b303d ${progress}% 100%)` }}><div className="grid h-[96px] w-[96px] place-items-center rounded-full bg-[#171b25] text-center"><span><strong className="block font-display text-2xl text-slate-100">{progress}%</strong><small className="text-[10px] text-slate-500">da trilha</small></span></div></div><div className="text-xs text-slate-400"><strong className="font-display text-lg text-slate-100">{mastered.length}<span className="text-slate-500">/{skills.length}</span></strong><p>habilidades<br />dominadas</p></div></div>
      </div>
    </section>
    <section className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Metric icon={Sparkles} label="Nível atual" value={`Nível ${level.level}`} accent="violet" detail={`${level.xpForNextLevel - level.xpIntoLevel} XP até o próximo nível`} progress={level.percentToNextLevel} />
      <Metric icon={Trophy} label="Experiência total" value={`${state.student.totalXp} XP`} accent="gold" detail="Sua jornada em números" />
      <Metric icon={CheckCircle2} label="Habilidades dominadas" value={`${mastered.length}`} accent="green" detail={skills.length ? `${skills.length - mastered.length} ainda pela frente` : 'Catálogo indisponível'} />
      <Metric icon={Clock3} label="Revisões pendentes" value={String(pendingReviews.length)} accent="violet" detail={dueReviewCount ? `${dueReviewCount} vencida${dueReviewCount === 1 ? '' : 's'}` : nextReview ? `Próxima: ${niceDate(nextReview.dueAt)}` : 'Sem revisões agendadas'} />
    </section>
    <section className="panel mb-5 p-5 sm:p-6">
      <div className="mb-4 flex items-center justify-between"><div><p className="eyebrow mb-2">MISSÕES</p><h2 className="font-display text-lg font-semibold text-slate-100">Próximos desafios</h2></div><Link href="/missoes" className="text-xs font-semibold text-violet-300 hover:text-violet-200" data-testid="link-dashboard-missions">Ver todas</Link></div>
      <div className="grid gap-3 sm:grid-cols-2">{upcomingMissions.map((mission) => <div key={mission.id} className="rounded-xl border border-[#2c3140] bg-[#141821] p-4"><div className="flex items-start justify-between gap-3"><div><h3 className="text-sm font-semibold text-slate-200">{mission.title}</h3><p className="mt-1 text-xs leading-5 text-slate-500">{mission.description}</p></div><span className="shrink-0 font-mono text-xs text-amber-200">{mission.rewardXp} XP</span></div><div className="mt-3 flex items-center justify-between gap-3"><span className="text-[10px] text-slate-600">{canCompleteMission(mission, state) ? 'Critério concluído' : 'Em andamento'}</span><Link href={`/habilidade/${mission.skillId}`} className="text-[11px] font-semibold text-violet-300 hover:text-violet-200">Ver habilidade</Link></div></div>)}</div>
    </section>
    <div className="grid gap-5 lg:grid-cols-[1.3fr_.7fr]">
      <section className="panel p-5 sm:p-6">
        <div className="mb-5 flex items-center justify-between"><div><p className="eyebrow mb-2">PRÓXIMO PASSO</p><h2 className="font-display text-lg font-semibold text-slate-100">Continue sua trilha</h2></div><Link href="/trilha" className="text-xs font-semibold text-violet-300 hover:text-violet-200" data-testid="link-see-all-skills">Ver todas</Link></div>
        {nextSkill ? <SkillRow skill={nextSkill} status={skillStatus(nextSkill.id)} /> : <div className="empty-state"><CheckCircle2 className="mx-auto mb-3 text-emerald-300" /><p className="font-semibold text-slate-200">Trilha concluída</p><p className="mt-1 text-sm text-slate-500">Você dominou todas as habilidades disponíveis.</p></div>}
      </section>
      <section className="panel p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><div><p className="eyebrow mb-2">ATIVIDADE RECENTE</p><h2 className="font-display text-lg font-semibold text-slate-100">Sua jornada</h2></div><Activity size={17} className="text-slate-500" /></div>
        {recent.length ? <div className="space-y-4">{recent.map((event: AnyRecord, index) => <div key={event.id || index} className="flex gap-3"><span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-violet-300/10 text-violet-200"><Check size={14} /></span><div className="min-w-0 flex-1"><p className="text-sm text-slate-300">{itemText(event, ['description', 'title', 'label'], 'Atividade registrada')}</p><p className="mt-1 text-[11px] text-slate-600">{niceDate(event.createdAt || event.at || event.date)}</p></div></div>)}</div> : <p className="text-sm text-slate-500">Sua primeira conquista vai aparecer aqui.</p>}
      </section>
    </div>
  </div>;
}
function Metric({ icon: Icon, label, value, detail, accent, progress }: { icon: typeof Trophy; label: string; value: string; detail: string; accent: string; progress?: number }) {
  const color = accent === 'gold' ? 'text-amber-300 bg-amber-300/10' : accent === 'green' ? 'text-emerald-300 bg-emerald-300/10' : 'text-violet-300 bg-violet-300/10';
  return <article className="panel p-4"><div className="flex items-start justify-between"><span className="text-xs font-semibold text-slate-500">{label}</span><span className={`grid h-8 w-8 place-items-center rounded-lg ${color}`}><Icon size={16} /></span></div><strong className="mt-3 block font-display text-2xl text-slate-100">{value}</strong>{progress !== undefined && <div className="mt-3 meter" aria-label={`${progress}% do progresso até o próximo nível`}><span style={{ width: `${progress}%` }} /></div>}<p className="mt-1 text-[11px] text-slate-500">{detail}</p></article>;
}
function SkillRow({ skill, status }: { skill: Skill; status: unknown }) {
  const open = !isLocked(status);
  return <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#2c3140] bg-[#141821] p-4 sm:p-5"><div className="flex min-w-0 items-start gap-3"><span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-violet-300/10 text-violet-200"><BookOpen size={17} /></span><div className="min-w-0"><div className="mb-1 flex flex-wrap items-center gap-2"><h3 className="font-semibold text-slate-100">{skill.name}</h3><StatusPill status={status} /></div><p className="line-clamp-2 text-xs leading-5 text-slate-500">{skill.description}</p><p className="mt-2 text-[10px] font-semibold uppercase tracking-wider text-slate-600">{skill.subject} · {skill.difficulty}</p></div></div><Link href={`/habilidade/${skill.id}`} className={`action-secondary ${!open ? 'pointer-events-none opacity-50' : ''}`} aria-disabled={!open} data-testid={`button-open-skill-${skill.id}`}>Detalhes <ArrowRight size={14} /></Link></div>;
}

function Trail() {
  const { skillStatus } = useStudyQuest();
  const [listMode, setListMode] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(max-width: 800px)').matches,
  );
  const [zoom, setZoom] = useState(1);
  const subjects = [...new Set(skills.map((s) => s.subject))];
  const sorted = [...skills].sort((a, b) => a.order.y - b.order.y || a.order.x - b.order.x);
  const minY = Math.min(...skills.map((s) => s.order.y));
  const width = Math.max(1100, ...skills.map((s) => s.order.x * 210 + 230));
  const height = Math.max(650, ...skills.map((s) => (s.order.y - minY) * 155 + 130));
  return <div className="main-content fade-in"><PageHeading overline="MAPA DE CONHECIMENTO" title="Sua trilha" description="Uma habilidade de cada vez. Domine os fundamentos para abrir novos caminhos." action={<button className="action-secondary" onClick={() => setListMode(!listMode)} data-testid="button-toggle-trail-view">{listMode ? <Map size={15} /> : <List size={15} />}{listMode ? 'Ver mapa' : 'Ver lista'}</button>} />
    <p className="mb-5 rounded-lg border border-amber-800/30 bg-amber-950/15 px-4 py-3 text-xs leading-5 text-amber-100/70">Esta trilha é uma base didática ilustrativa. Os pré-requisitos e conteúdos devem ser conferidos com a ementa da instituição de ensino desejada.</p>
    <div className="mb-5 flex flex-wrap gap-2">{subjects.map((subject) => <span key={subject} className="rounded-full border border-[#303543] bg-[#171b25] px-3 py-1.5 text-[11px] text-slate-400">{subject}</span>)}</div>
    <div className="mb-4 flex flex-wrap gap-x-5 gap-y-2 text-[11px] text-slate-500" aria-label="Legenda da trilha">
      <span className="inline-flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full bg-violet-300" />Disponível ou em aprendizado</span>
      <span className="inline-flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full bg-emerald-300" />Dominada</span>
      <span className="inline-flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full bg-amber-300" />Revisão pendente</span>
      <span className="inline-flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full bg-slate-600" />Bloqueada</span>
    </div>
    {!listMode && <div className="mb-3 flex items-center justify-end gap-2"><span className="mr-1 text-[11px] text-slate-500">Zoom {Math.round(zoom * 100)}%</span><button className="action-secondary !min-h-8 !px-2.5" onClick={() => setZoom((value) => Math.max(0.6, Math.round((value - 0.1) * 10) / 10))} aria-label="Diminuir zoom da trilha" data-testid="button-trail-zoom-out"><Minus size={14} /></button><button className="action-secondary !min-h-8 !px-2.5" onClick={() => setZoom(1)} aria-label="Redefinir zoom da trilha" data-testid="button-trail-zoom-reset">100%</button><button className="action-secondary !min-h-8 !px-2.5" onClick={() => setZoom((value) => Math.min(1.4, Math.round((value + 0.1) * 10) / 10))} aria-label="Aumentar zoom da trilha" data-testid="button-trail-zoom-in"><Plus size={14} /></button></div>}
    {skills.length ? listMode ? <div className="space-y-3">{sorted.map((skill) => <SkillRow key={skill.id} skill={skill} status={skillStatus(skill.id)} />)}</div> :
      <section className="panel overflow-auto p-3 sm:p-5" aria-label="Mapa interativo de habilidades"><div style={{ width: width * zoom, height: height * zoom }}><div className="tree-canvas min-w-[950px] rounded-lg" style={{ width, height, transform: `scale(${zoom})`, transformOrigin: 'top left' }}>
        <svg aria-hidden="true" className="absolute inset-0 h-full w-full" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
          {skills.flatMap((skill) => skill.prerequisites.map((preId) => { const pre = getSkill(preId); return pre ? <line key={`${preId}-${skill.id}`} x1={pre.order.x * 210 + 115} y1={(pre.order.y - minY) * 155 + 85} x2={skill.order.x * 210 + 115} y2={(skill.order.y - minY) * 155 + 85} stroke={isMastered(skillStatus(preId)) ? '#527c67' : '#3a3e4c'} strokeWidth="2" strokeDasharray={isMastered(skillStatus(preId)) ? undefined : '5 7'} /> : null; }))}
        </svg>
        {skills.map((skill) => { const status = skillStatus(skill.id); return <Link key={skill.id} href={`/habilidade/${skill.id}`} className={`skill-node ${status === 'review-due' ? 'review-due' : isMastered(status) ? 'mastered' : ''} ${isLocked(status) ? 'locked' : ''}`} style={{ left: skill.order.x * 210 + 115, top: (skill.order.y - minY) * 155 + 85 }} data-testid={`skill-node-${skill.id}`}><div className="mb-2 flex items-center justify-between gap-2"><span className="eyebrow !text-[9px]">{skill.subject}</span>{isLocked(status) ? <LockKeyhole size={13} className="text-slate-500" /> : isMastered(status) ? <CheckCircle2 size={14} className="text-emerald-300" /> : <Sparkles size={13} className="text-violet-300" />}</div><strong className="block text-xs leading-4">{skill.name}</strong><span className="mt-2 block text-[10px] text-slate-500">{titleCaseStatus(status)}</span></Link>; })}
       </div></div></section> : <div className="empty-state"><Map className="mx-auto mb-3 text-violet-300" /><p className="font-semibold text-slate-200">Trilha em preparação</p><p className="mt-1 text-sm text-slate-500">As habilidades aparecerão aqui quando o catálogo estiver disponível.</p></div>}
  </div>;
}

function SkillDetail() {
  const params = useParams<{ skillId: string }>();
  const { state, skillStatus } = useStudyQuest();
  const skill = params.skillId ? getSkill(params.skillId) : undefined;
  if (!skill) return <NotFoundPage />;
  const status = skillStatus(skill.id);
  const blockers = getPrereqBlockers(skill, skillStatus);
  const dependents = skills.filter((item) => item.prerequisites.includes(skill.id));
  const contentReady = skill.contentStatus === 'ready';
  const history = state.skillProgress[skill.id]?.attempts ?? [];
  const nextReview = state.reviewSchedule
    .filter((review) => review.skillId === skill.id && !review.completedAt)
    .sort((a, b) => a.dueAt.localeCompare(b.dueAt))[0];
  return <div className="main-content fade-in"><Link href="/trilha" className="mb-6 inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-200" data-testid="link-back-trail"><ArrowLeft size={14} />Voltar à trilha</Link>
    <PageHeading overline={`${skill.subject} · ${skill.category}`} title={skill.name} description={skill.description} action={<StatusPill status={status} />} />
    <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
      <div className="space-y-5">
        <section className="panel p-5 sm:p-6"><p className="eyebrow mb-4">ANTES DE COMEÇAR</p><h2 className="font-display text-lg font-semibold text-slate-100">Pré-requisitos</h2>
          {skill.prerequisites.length ? <div className="mt-4 space-y-2">{skill.prerequisites.map((id) => { const pre = getSkill(id); const done = isMastered(skillStatus(id)); return <Link key={id} href={`/habilidade/${id}`} className="flex items-center justify-between rounded-lg border border-[#2b303d] bg-[#141821] p-3" data-testid={`link-prerequisite-${id}`}><span className="flex items-center gap-3 text-sm text-slate-300">{done ? <CheckCircle2 size={16} className="text-emerald-300" /> : <LockKeyhole size={15} className="text-slate-500" />}{pre?.name || id}</span><ChevronRight size={15} className="text-slate-600" /></Link>; })}</div> : <p className="mt-3 text-sm text-slate-500">Nenhum pré-requisito. Este é um ponto de partida.</p>}
          {!!blockers.length && <p className="mt-4 rounded-lg border border-amber-700/30 bg-amber-950/20 px-3 py-2.5 text-xs leading-5 text-amber-200/80">Para liberar esta habilidade, domine: {blockers.map((b) => b.name).join(', ')}.</p>}
        </section>
        <section className="panel p-5 sm:p-6"><p className="eyebrow mb-3">POR QUE ISSO IMPORTA</p><p className="text-sm leading-6 text-slate-300">{skill.importance}</p>
          <div className="mt-5 border-t border-[#292e3b] pt-4"><p className="eyebrow mb-3">CAMINHOS QUE DEPENDEM DELA</p>{dependents.length ? <div className="flex flex-wrap gap-2">{dependents.map((item) => <Link key={item.id} href={`/habilidade/${item.id}`} className="rounded-lg border border-[#303543] bg-[#171b25] px-3 py-2 text-xs text-slate-300 hover:border-violet-700/50" data-testid={`link-unlocked-skill-${item.id}`}>{item.name}</Link>)}</div> : <p className="text-xs text-slate-500">Esta habilidade não possui dependências diretas no catálogo.</p>}</div>
        </section>
        <section className="panel p-5 sm:p-6"><p className="eyebrow mb-4">ROTEIRO DE ESTUDO</p><h2 className="font-display text-lg font-semibold text-slate-100">O que você vai aprender</h2>
          {skill.lessonSteps.length ? <div className="mt-4 space-y-2">{skill.lessonSteps.map((step: AnyRecord, i) => <div key={step.id || i} className="flex gap-3 rounded-lg border border-[#292e3b] p-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-[#242938] font-mono text-[10px] text-violet-200">{String(i + 1).padStart(2, '0')}</span><div><p className="text-sm font-medium text-slate-200">{itemText(step, ['title', 'name'], 'Etapa de estudo')}</p><p className="mt-1 text-xs text-slate-500">{itemText(step, ['description', 'content'], '')}</p></div></div>)}</div> : <div className="mt-4 rounded-lg border border-amber-700/30 bg-amber-950/20 p-4 text-sm text-amber-100/80"><ShieldAlert size={17} className="mb-2 text-amber-300" /><p>O conteúdo desta habilidade ainda não está disponível. Nenhuma aula foi iniciada.</p></div>}
        </section>
      </div>
      <aside className="panel h-fit p-5"><p className="eyebrow mb-4">SUA PRÓXIMA JOGADA</p><div className="mb-4 flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-violet-300/10 text-violet-200"><BookOpen size={18} /></span><div><p className="text-sm font-semibold text-slate-100">Lição guiada</p><p className="text-xs text-slate-500">{skill.lessonSteps.length} etapas de estudo</p></div></div>
        {!skill.lessonSteps.length || !contentReady ? <button className="action-primary w-full cursor-not-allowed opacity-50" disabled data-testid="button-lesson-unavailable">Conteúdo indisponível</button> : blockers.length ? <button className="action-primary w-full cursor-not-allowed opacity-50" disabled data-testid="button-lesson-locked"><LockKeyhole size={15} />Habilidade bloqueada</button> : <Link href={`/estudo/${skill.id}`} className="action-primary w-full" data-testid="button-start-lesson"><BookOpen size={15} />Começar lição <ArrowRight size={14} /></Link>}
         <div className="mt-5 border-t border-[#292e3b] pt-4"><div className="flex justify-between text-xs text-slate-500"><span>Dificuldade</span><strong className="font-semibold text-slate-300">{skill.difficulty}</strong></div><div className="mt-3 flex justify-between text-xs text-slate-500"><span>XP por etapa</span><strong className="font-mono text-slate-300">10 XP</strong></div><div className="mt-3 flex justify-between text-xs text-slate-500"><span>Etapas</span><strong className="font-mono text-slate-300">{skill.lessonSteps.length}</strong></div><div className="mt-3 flex justify-between text-xs text-slate-500"><span>Questões</span><strong className="font-mono text-slate-300">{skill.questions.length}</strong></div>{nextReview && <div className="mt-3 flex justify-between gap-3 text-xs text-slate-500"><span>Próxima revisão</span><strong className="font-mono text-slate-300">{niceDate(nextReview.dueAt)}</strong></div>}</div>
         {!!history.length && <div className="mt-5 border-t border-[#292e3b] pt-4"><p className="eyebrow mb-3">AVALIAÇÕES RECENTES</p><div className="space-y-2">{history.slice(-3).reverse().map((attempt) => <div key={attempt.id} className="flex items-center justify-between gap-3 text-xs"><span className="text-slate-500">{attempt.mode === 'diagnostic' ? 'Diagnóstico' : attempt.mode === 'practice' ? 'Prática' : 'Domínio'}</span><span className={attempt.passed ? 'text-emerald-300' : 'text-slate-300'}>{attempt.scorePercent}%</span></div>)}</div></div>}
        {skill.questions.length > 0 && <div className="mt-4 grid gap-2"><Link href={`/avaliacao/${skill.id}/diagnostic`} className={`action-secondary w-full ${blockers.length ? 'pointer-events-none opacity-50' : ''}`} aria-disabled={!!blockers.length} data-testid="button-diagnostic">Avaliação diagnóstica</Link><Link href={`/avaliacao/${skill.id}/practice`} className={`action-secondary w-full ${blockers.length ? 'pointer-events-none opacity-50' : ''}`} aria-disabled={!!blockers.length} data-testid="button-practice">Praticar questões</Link></div>}
      </aside>
    </div>
  </div>;
}

function Lesson() {
  const params = useParams<{ skillId: string }>();
  const { state, skillStatus, startLesson, completeLessonStep } = useStudyQuest();
  const skill = params.skillId ? getSkill(params.skillId) : undefined;
  const [started, setStarted] = useState(false);
  if (!skill) return <NotFoundPage />;
  const progress = state.skillProgress[skill.id];
  const completed = progress?.completedSteps || [];
  const blockers = getPrereqBlockers(skill, skillStatus);
  const ready = skill.contentStatus === 'ready';
  const begin = () => { startLesson(skill.id); setStarted(true); };
  if (!ready || !skill.lessonSteps.length) return <div className="main-content"><Link href={`/habilidade/${skill.id}`} className="action-secondary"><ArrowLeft size={14} />Voltar à habilidade</Link><div className="empty-state mt-8"><ShieldAlert className="mx-auto mb-3 text-amber-300" /><h1 className="font-display text-xl font-semibold text-slate-100">Lição indisponível</h1><p className="mt-2 text-sm text-slate-500">O conteúdo desta habilidade ainda não foi preparado.</p></div></div>;
  if (blockers.length) return <div className="main-content"><div className="empty-state"><LockKeyhole className="mx-auto mb-3 text-slate-400" /><h1 className="font-display text-xl font-semibold text-slate-100">Esta etapa está bloqueada</h1><p className="mt-2 text-sm text-slate-500">Domine primeiro: {blockers.map((x) => x.name).join(', ')}.</p><Link href={`/habilidade/${skill.id}`} className="action-secondary mt-5">Voltar aos detalhes</Link></div></div>;
  const allDone = skill.lessonSteps.every((s: AnyRecord) => completed.includes(s.id));
  return <div className="main-content fade-in max-w-4xl"><Link href={`/habilidade/${skill.id}`} className="mb-6 inline-flex items-center gap-2 text-xs text-slate-500 hover:text-white" data-testid="link-back-skill"><ArrowLeft size={14} />{skill.name}</Link>
    <div className="mb-7 flex flex-wrap items-end justify-between gap-3"><div><p className="eyebrow mb-2">LIÇÃO GUIADA · {skill.subject}</p><h1 className="page-title">{skill.name}</h1></div><span className="text-xs text-slate-500">{completed.length} de {skill.lessonSteps.length} etapas</span></div>
    <div className="mb-6 meter"><span style={{ width: `${skill.lessonSteps.length ? completed.length / skill.lessonSteps.length * 100 : 0}%` }} /></div>
    {!started && <div className="panel mb-5 flex flex-wrap items-center justify-between gap-4 p-5"><div><h2 className="font-display text-base font-semibold text-slate-100">{completed.length ? 'Retome de onde parou' : 'Pronto para começar?'}</h2><p className="mt-1 text-sm text-slate-500">{completed.length ? `${completed.length} etapa${completed.length === 1 ? '' : 's'} já concluída${completed.length === 1 ? '' : 's'}.` : 'Seu progresso será registrado enquanto avança pelas etapas.'}</p></div><button className="action-primary" onClick={begin} data-testid="button-begin-lesson"><BookOpen size={15} />{completed.length ? 'Continuar lição' : 'Iniciar lição'}</button></div>}
    <div className="space-y-3">{skill.lessonSteps.map((step: AnyRecord, i) => { const done = completed.includes(step.id); const expanded = started || completed.length > 0 || i === 0; return <article key={step.id || i} className={`panel p-5 ${done ? 'border-emerald-900/70' : ''}`}><div className="flex gap-4"><span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg font-mono text-xs ${done ? 'bg-emerald-400/10 text-emerald-300' : 'bg-violet-300/10 text-violet-200'}`}>{done ? <Check size={15} /> : String(i + 1).padStart(2, '0')}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-start justify-between gap-2"><h2 className="font-display text-base font-semibold text-slate-100">{itemText(step, ['title', 'name'], `Etapa ${i + 1}`)}</h2>{done && <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">Concluída</span>}</div>{expanded && <div className="prose prose-invert mt-3 max-w-none text-sm leading-7 text-slate-300"><p>{itemText(step, ['content', 'body', 'description', 'text'], '')}</p>{typeof step.example === 'string' && step.example && <div className="not-prose mt-4 rounded-lg border border-[#343140] bg-[#1d1a27] p-4"><p className="mb-2 text-[10px] font-bold uppercase tracking-[.14em] text-violet-200">Exemplo</p><p className="whitespace-pre-line text-sm leading-6 text-slate-300">{step.example}</p></div>}</div>}{!expanded && <p className="mt-2 text-xs text-slate-500">Inicie a lição para acessar esta etapa.</p>}{expanded && !done && <button disabled={!started} onClick={() => { completeLessonStep(skill.id, step.id); if (!started) setStarted(true); }} className="action-secondary mt-4 disabled:cursor-not-allowed disabled:opacity-50" data-testid={`button-complete-step-${step.id}`}><Check size={14} />Marcar etapa como concluída</button>}</div></div></article>; })}</div>
    {allDone && <div className="panel mt-5 flex flex-wrap items-center justify-between gap-4 border-emerald-900/60 p-5"><div><p className="eyebrow !text-emerald-300">ETAPAS CONCLUÍDAS</p><p className="mt-1 text-sm text-slate-300">Hora de verificar o que você aprendeu.</p></div>{skill.questions.length ? <Link href={`/avaliacao/${skill.id}/mastery`} className="action-primary" data-testid="button-go-mastery">Avaliação de domínio <ArrowRight size={14} /></Link> : <p className="text-xs text-slate-500">A avaliação ainda não está disponível para esta habilidade.</p>}</div>}
  </div>;
}

function Assessment() {
  const params = useParams<{ skillId: string; mode: string }>();
  const { state, skillStatus, submitAssessment } = useStudyQuest();
  const skill = params.skillId ? getSkill(params.skillId) : undefined;
  const mode = (['diagnostic', 'practice', 'mastery'].includes(params.mode || '') ? params.mode : 'practice') as Mode;
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  if (!skill) return <NotFoundPage />;
  const blockers = getPrereqBlockers(skill, skillStatus);
  const questions = skill.questions || [];
  const label = mode === 'mastery' ? 'Avaliação de domínio' : mode === 'diagnostic' ? 'Diagnóstico' : 'Prática';
  const attempts = (state.skillProgress[skill.id]?.attempts || []) as unknown as AnyRecord[];
  const lastAttempt = attempts[attempts.length - 1] as AnyRecord | undefined;
  const submit = () => {
    if (questions.some((q: AnyRecord) => !answers[q.id])) { setError('Responda todas as questões antes de enviar.'); return; }
    setError('');
    const attempt = submitAssessment(skill.id, mode, Object.fromEntries(questions.map((q: AnyRecord) => [q.id, answers[q.id]])));
    if (!attempt) { setError('Não foi possível registrar esta avaliação. Verifique se a habilidade está liberada e tente novamente.'); return; }
    setSubmitted(true);
  };
  if (skill.contentStatus !== 'ready') return <div className="main-content"><div className="empty-state"><ShieldAlert className="mx-auto mb-3 text-amber-300" /><h1 className="font-display text-xl text-slate-100">Avaliação indisponível</h1><p className="mt-2 text-sm text-slate-500">O conteúdo desta habilidade ainda não foi preparado.</p><Link href={`/habilidade/${skill.id}`} className="action-secondary mt-5">Voltar à habilidade</Link></div></div>;
  if (blockers.length || isLocked(skillStatus(skill.id))) return <div className="main-content"><div className="empty-state"><LockKeyhole className="mx-auto mb-3 text-slate-400" /><h1 className="font-display text-xl text-slate-100">Avaliação bloqueada</h1><p className="mt-2 text-sm text-slate-500">Domine primeiro: {blockers.length ? blockers.map((b) => b.name).join(', ') : 'os pré-requisitos desta habilidade'}.</p><Link href={`/habilidade/${skill.id}`} className="action-secondary mt-5">Ver pré-requisitos</Link></div></div>;
  if (isMastered(skillStatus(skill.id)) && mode !== 'practice') return <div className="main-content"><div className="empty-state"><CheckCircle2 className="mx-auto mb-3 text-emerald-300" /><h1 className="font-display text-xl text-slate-100">Habilidade já dominada</h1><p className="mt-2 text-sm text-slate-500">Você já demonstrou domínio. A prática continua disponível para manter o ritmo.</p><Link href={`/avaliacao/${skill.id}/practice`} className="action-primary mt-5">Praticar questões</Link></div></div>;
  if (!questions.length) return <div className="main-content"><Link href={`/habilidade/${skill.id}`} className="action-secondary"><ArrowLeft size={14} />Voltar</Link><div className="empty-state mt-8"><CircleHelp className="mx-auto mb-3 text-violet-300" /><h1 className="font-display text-xl text-slate-100">Questões indisponíveis</h1><p className="mt-2 text-sm text-slate-500">Ainda não há questões para esta habilidade.</p></div></div>;
  const complete = questions.every((q: AnyRecord) => answers[q.id]);
  return <div className="main-content fade-in max-w-4xl"><Link href={`/habilidade/${skill.id}`} className="mb-6 inline-flex items-center gap-2 text-xs text-slate-500 hover:text-slate-100" data-testid="link-back-assessment"><ArrowLeft size={14} />{skill.name}</Link>
    <PageHeading overline={`${skill.subject} · ${mode.toUpperCase()}`} title={label} description="As respostas e explicações aparecem depois do envio." />
     {submitted ? <section className="panel p-5 sm:p-7"><div className="mb-6 flex flex-wrap items-center justify-between gap-4"><div><p className="eyebrow mb-2">TENTATIVA REGISTRADA</p><h2 className="font-display text-2xl font-semibold text-slate-100">Avaliação concluída</h2></div><span className="rounded-xl border border-violet-700/40 bg-violet-950/30 px-4 py-3 text-sm font-bold text-violet-200">{typeof lastAttempt?.scorePercent === 'number' ? `${Math.round(lastAttempt.scorePercent)}%` : 'Resultado salvo'}</span></div>
      <div className="space-y-4">{questions.map((q: AnyRecord, index: number) => { const correct = answers[q.id] === q.correctOptionId; return <article key={q.id} className="rounded-xl border border-[#2e3341] bg-[#141821] p-4"><div className="mb-3 flex items-start gap-3"><span className="font-mono text-[11px] text-slate-500">{String(index + 1).padStart(2, '0')}</span><p className="text-sm font-semibold leading-6 text-slate-200">{q.prompt}</p></div><div className="space-y-2">{q.options.map((opt: AnyRecord) => <div key={opt.id} className={`rounded-lg border px-3 py-2.5 text-sm ${opt.id === q.correctOptionId ? 'border-emerald-800/60 bg-emerald-950/30 text-emerald-200' : opt.id === answers[q.id] ? 'border-rose-900/60 bg-rose-950/20 text-rose-200' : 'border-[#292e3b] text-slate-500'}`}><span className="mr-2 font-mono text-[10px] opacity-70">{opt.id}</span>{opt.text}{opt.id === answers[q.id] && <span className="ml-2 text-[10px]">{correct ? 'Sua resposta · correta' : 'Sua resposta'}</span>}</div>)}</div><p className="mt-3 border-t border-[#292e3b] pt-3 text-xs leading-5 text-slate-400"><strong className="text-slate-300">Por quê: </strong>{q.explanation}</p></article>; })}</div>
      <div className="mt-6 flex flex-wrap gap-3"><Link href={`/habilidade/${skill.id}`} className="action-secondary" data-testid="button-back-to-skill">Voltar à habilidade</Link><button className="action-primary" onClick={() => { setAnswers({}); setSubmitted(false); }} data-testid="button-retry-assessment">Tentar novamente <RotateCcw size={14} /></button></div>
    </section> :
    <section className="panel p-5 sm:p-7"><div className="mb-5 flex items-center justify-between text-xs text-slate-500"><span>{questions.length} questões</span><span>{Object.keys(answers).length}/{questions.length} respondidas</span></div><div className="space-y-6">{questions.map((q: AnyRecord, index: number) => <fieldset key={q.id} className="border-b border-[#292e3b] pb-6 last:border-0"><legend className="mb-4 flex gap-3 text-sm font-semibold leading-6 text-slate-200"><span className="font-mono text-[11px] text-violet-300">{String(index + 1).padStart(2, '0')}</span>{q.prompt}</legend><div className="space-y-2">{q.options.map((opt: AnyRecord) => <button type="button" key={opt.id} onClick={() => setAnswers({ ...answers, [q.id]: opt.id })} className={`answer-option ${answers[q.id] === opt.id ? 'selected' : ''}`} data-testid={`answer-${q.id}-${opt.id}`}><span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border text-[10px] ${answers[q.id] === opt.id ? 'border-violet-300 bg-violet-300 text-[#171323]' : 'border-[#505665] text-slate-500'}`}>{answers[q.id] === opt.id ? <Check size={12} /> : opt.id}</span><span className="text-sm leading-5 text-slate-300">{opt.text}</span></button>)}</div></fieldset>)}</div>
      {error && <p role="alert" className="mt-4 rounded-lg border border-rose-900/50 bg-rose-950/20 p-3 text-sm text-rose-200">{error}</p>}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3"><p className="text-xs text-slate-500">As explicações serão exibidas após o envio.</p><button disabled={!complete} onClick={submit} className="action-primary disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-submit-assessment">Enviar respostas <ArrowRight size={14} /></button></div>
    </section>}
  </div>;
}

function Missions() {
  const { state, completeMission } = useStudyQuest();
  const done = state.completedMissions;
  const available = missions as Mission[];
  const remaining = available.filter((m: AnyRecord) => !done.includes(m.id));
  const canClaim = (mission: Mission) => {
    return canCompleteMission(mission, state);
  };
  return <div className="main-content fade-in"><PageHeading overline="DESAFIOS OPCIONAIS" title="Missões" description="Pequenos objetivos para manter o ritmo e reconhecer cada avanço." />
    <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-3"><Metric icon={Flag} label="Concluídas" value={String(done.length)} detail="Missões encerradas" accent="violet" /><Metric icon={Trophy} label="No horizonte" value={String(remaining.length)} detail="Desafios disponíveis" accent="gold" /></div>
    {available.length ? <div className="grid gap-3 md:grid-cols-2">{available.map((mission) => { const complete = done.includes(mission.id); const eligible = canClaim(mission); const title = itemText(mission, ['title', 'name'], 'Missão'); const desc = itemText(mission, ['description', 'detail'], ''); return <article key={mission.id} className={`panel p-5 ${complete ? 'opacity-70' : ''}`}><div className="flex gap-4"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${complete ? 'bg-emerald-300/10 text-emerald-300' : 'bg-amber-300/10 text-amber-200'}`}>{complete ? <CheckCircle2 size={19} /> : <Flag size={19} />}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="font-display text-base font-semibold text-slate-100">{title}</h2><span className="font-mono text-xs text-amber-200">{mission.rewardXp} XP</span></div><p className="mt-2 text-sm leading-6 text-slate-400">{desc}</p>{mission.skillId && <Link href={`/habilidade/${mission.skillId}`} className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-violet-300" data-testid={`link-mission-skill-${mission.id}`}>Ver habilidade <ChevronRight size={13} /></Link>}{complete ? <div className="mt-4 text-xs font-semibold text-emerald-300">Missão concluída</div> : <><button disabled={!eligible} onClick={() => completeMission(mission.id)} className="action-secondary mt-4 disabled:cursor-not-allowed disabled:opacity-40" title={eligible ? 'Resgatar recompensa' : 'Conclua o critério descrito para liberar'} data-testid={`button-complete-mission-${mission.id}`}><Check size={14} />Concluir missão</button>{!eligible && <p className="mt-2 text-[11px] text-slate-600">Conclua o critério para liberar a recompensa.</p>}</>}</div></div></article>; })}</div> : <div className="empty-state"><Flag className="mx-auto mb-3 text-amber-200" /><p className="font-semibold text-slate-200">Nenhuma missão disponível</p><p className="mt-1 text-sm text-slate-500">Novos desafios aparecerão por aqui.</p></div>}
  </div>;
}

function Reviews() {
  const { state, completeReview, skillStatus } = useStudyQuest();
  const [feedback, setFeedback] = useState('');
  const entries = state.reviewSchedule as ReviewEntry[];
  const pending = entries.filter((r) => !r.completedAt);
  const completedEntries = entries.filter((r) => Boolean(r.completedAt));
  return <div className="main-content fade-in"><PageHeading overline="MEMÓRIA DE LONGO PRAZO" title="Revisões" description="Revisitar no momento certo ajuda o conhecimento a permanecer." />
    {feedback && <div role="status" className="mb-4 flex items-center justify-between rounded-lg border border-emerald-800/50 bg-emerald-950/20 p-3 text-sm text-emerald-200">{feedback}<button onClick={() => setFeedback('')} aria-label="Fechar mensagem"><X size={14} /></button></div>}
     {pending.length ? <div className="space-y-3">{pending.map((entry) => { const skill = getSkill(entry.skillId); const isDue = new Date(entry.dueAt).getTime() <= Date.now(); return <article key={entry.id} className="panel flex flex-wrap items-center justify-between gap-4 p-5"><div className="flex items-start gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-violet-300/10 text-violet-200"><RotateCcw size={16} /></span><div><p className="font-semibold text-slate-100">{skill?.name || entry.skillId}</p><p className="mt-1 text-xs text-slate-500">Agendada para {niceDate(entry.dueAt)}</p>{skill && <p className="mt-1 text-[11px] text-slate-600">{skill.subject} · {titleCaseStatus(skillStatus(skill.id))}</p>}</div></div><div className="flex flex-wrap items-center gap-2">{skill && skill.questions.length > 0 && <Link href={`/avaliacao/${skill.id}/practice`} className={`action-secondary ${!isDue ? 'pointer-events-none opacity-40' : ''}`} aria-disabled={!isDue} data-testid={`button-review-practice-${entry.id}`}>Revisar questões <ArrowRight size={14} /></Link>}<button disabled={!isDue} onClick={() => { const done = completeReview(entry.skillId, entry.id, true); setFeedback(done ? 'Revisão concluída. O próximo intervalo foi agendado.' : 'Faça uma prática com pelo menos 80% de acertos depois da data da revisão para confirmar o domínio.'); }} className="action-secondary disabled:cursor-not-allowed disabled:opacity-40" data-testid={`button-review-passed-${entry.id}`}><Check size={14} />Concluí</button><button disabled={!isDue} onClick={() => { const done = completeReview(entry.skillId, entry.id, false); setFeedback(done ? 'Dificuldade registrada. Uma nova revisão será agendada para amanhã.' : 'Esta revisão já foi concluída.'); }} className="action-secondary disabled:cursor-not-allowed disabled:opacity-40" data-testid={`button-review-retry-${entry.id}`}>Reforçar</button></div></article>; })}</div> : <div className="empty-state"><CheckCircle2 className="mx-auto mb-3 text-emerald-300" /><h2 className="font-display font-semibold text-slate-200">Tudo em dia</h2><p className="mt-1 text-sm text-slate-500">Quando houver revisões recomendadas, elas estarão aqui.</p><Link href="/trilha" className="action-secondary mt-5" data-testid="button-reviews-trail">Explorar trilha</Link></div>}
     {!!completedEntries.length && <section className="mt-8"><p className="eyebrow mb-3">HISTÓRICO</p><div className="space-y-2">{completedEntries.map((entry) => <div key={entry.id} className="flex items-center justify-between rounded-lg border border-[#292e3b] bg-[#151923] px-4 py-3 text-xs"><span className="text-slate-400">{getSkill(entry.skillId)?.name || entry.skillId}</span><span className={entry.passed ? 'text-emerald-300' : 'text-amber-300'}>{entry.passed ? 'Concluída' : 'Reforço recomendado'} · {niceDate(entry.completedAt)}</span></div>)}</div></section>}
  </div>;
}

function Profile() {
  const { state, exportBackup, importBackup, resetProgress } = useStudyQuest();
  const fileRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState<{ type: 'ok' | 'error'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const level = getLevelProgress(state.student.totalXp);
  const attempts = Object.entries(state.skillProgress)
    .flatMap(([skillId, progress]) => progress.attempts.map((attempt) => ({
      ...attempt,
      skillName: getSkill(skillId)?.name ?? skillId,
    })))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const recentActivity = state.activity.slice(0, 8);
  const completedReviews = state.reviewSchedule.filter((review) => review.completedAt);
  const pendingReviewCount = state.reviewSchedule.filter((review) => !review.completedAt).length;
  const exportData = () => {
    try { const content = exportBackup(); const blob = new Blob([content], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `studyquest-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click(); URL.revokeObjectURL(url); setMessage({ type: 'ok', text: 'Backup exportado com sucesso.' }); }
    catch { setMessage({ type: 'error', text: 'Não foi possível exportar seus dados. Tente novamente.' }); }
  };
  const importFile = async (file?: File) => {
    if (!file) return;
    setBusy(true); setMessage(null);
    try {
      const json = await file.text();
      const parsed = JSON.parse(json);
      const candidate = parsed?.state ?? parsed;
      if (!candidate || typeof candidate !== 'object' || candidate.version !== 1 || !candidate.student || !candidate.goal || !candidate.skillProgress || !Array.isArray(candidate.activity) || !Array.isArray(candidate.completedMissions) || !Array.isArray(candidate.reviewSchedule)) throw new Error('Esse arquivo não parece ser um backup StudyQuest válido.');
      if (!window.confirm('Importar este backup substituirá seu progresso atual. Deseja continuar?')) { setBusy(false); return; }
       importBackup(JSON.stringify(candidate));
      setMessage({ type: 'ok', text: 'Backup importado. Seus dados foram atualizados.' });
    } catch (error) { setMessage({ type: 'error', text: error instanceof SyntaxError ? 'O arquivo não contém JSON válido.' : error instanceof Error ? error.message : 'Falha ao importar o backup.' }); }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = ''; }
  };
  const reset = () => { if (window.confirm('Isso apagará todo o seu progresso e não poderá ser desfeito. Deseja continuar?')) { resetProgress(); setMessage({ type: 'ok', text: 'Seu progresso foi reiniciado.' }); } };
  return <div className="main-content fade-in"><PageHeading overline="PREFERÊNCIAS E DADOS" title="Seu perfil" description="Suas informações de jornada ficam neste dispositivo." />
    {message && <div role="status" className={`mb-5 flex items-center justify-between rounded-lg border p-3 text-sm ${message.type === 'error' ? 'border-rose-900/50 bg-rose-950/20 text-rose-200' : 'border-emerald-800/50 bg-emerald-950/20 text-emerald-200'}`} data-testid="profile-feedback">{message.text}<button onClick={() => setMessage(null)} aria-label="Fechar mensagem"><X size={14} /></button></div>}
    <div className="grid gap-5 lg:grid-cols-[.85fr_1.15fr]">
      <section className="panel p-5 sm:p-6"><p className="eyebrow mb-4">IDENTIDADE</p><div className="flex items-center gap-4"><span className="grid h-14 w-14 place-items-center rounded-2xl border border-violet-300/20 bg-violet-300/10 font-display text-xl font-semibold text-violet-100">{state.student.name?.trim()?.slice(0, 1)?.toUpperCase() || 'E'}</span><div><h2 className="font-display text-lg font-semibold text-slate-100">{state.student.name || 'Estudante'}</h2><p className="text-xs text-slate-500">Nível {level.level} · Aprendiz em jornada</p></div></div><div className="mt-6 grid grid-cols-2 gap-3"><div className="rounded-lg bg-[#121620] p-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Experiência</p><strong className="mt-1 block font-display text-xl text-amber-200">{state.student.totalXp} XP</strong></div><div className="rounded-lg bg-[#121620] p-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Habilidades</p><strong className="mt-1 block font-display text-xl text-emerald-200">{skills.filter((s) => isMastered(state.skillProgress[s.id]?.status)).length}</strong></div></div><Link href="/objetivo" className="action-secondary mt-5 w-full" data-testid="button-profile-goal"><Target size={15} />Editar objetivo acadêmico</Link></section>
      <section className="panel p-5 sm:p-6"><p className="eyebrow mb-1">PORTABILIDADE</p><h2 className="font-display text-lg font-semibold text-slate-100">Seus dados, sob seu controle</h2><p className="mt-2 text-sm leading-6 text-slate-400">Exporte seu progresso para guardar uma cópia ou importe um backup anterior. Seus dados não saem deste dispositivo.</p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2"><button className="action-secondary justify-start" onClick={exportData} data-testid="button-export-backup"><Download size={16} />Exportar backup</button><button className="action-secondary justify-start" onClick={() => fileRef.current?.click()} disabled={busy} data-testid="button-import-backup"><Upload size={16} />{busy ? 'Importando…' : 'Importar backup'}</button><input ref={fileRef} className="hidden" type="file" accept="application/json,.json" onChange={(e) => importFile(e.target.files?.[0])} data-testid="input-backup-file" /></div>
        <div className="mt-4 flex items-start gap-2 rounded-lg border border-[#2b303d] bg-[#141821] p-3 text-xs leading-5 text-slate-500"><FileUp size={15} className="mt-0.5 shrink-0 text-slate-400" /><span>A importação substitui o progresso atual. Confirme antes de aplicar. Use apenas arquivos exportados pelo StudyQuest.</span></div>
      </section>
    </div>
    <section className="mt-5 grid gap-5 lg:grid-cols-2">
      <article className="panel p-5"><div className="mb-4 flex items-center justify-between"><div><p className="eyebrow mb-2">LINHA DO TEMPO</p><h2 className="font-display text-lg font-semibold text-slate-100">Atividades recentes</h2></div><Activity size={17} className="text-violet-300" /></div>{recentActivity.length ? <div className="space-y-3">{recentActivity.map((event) => <div key={event.id} className="flex items-start justify-between gap-3 border-b border-[#292e3b] pb-3 last:border-0 last:pb-0"><div><p className="text-xs font-medium text-slate-300">{event.description}</p><p className="mt-1 text-[10px] text-slate-600">{niceDate(event.createdAt)}</p></div>{event.xp > 0 && <span className="shrink-0 font-mono text-[10px] text-amber-200">+{event.xp} XP</span>}</div>)}</div> : <p className="text-sm text-slate-500">As atividades aparecerão conforme você avançar.</p>}</article>
      <article className="panel p-5"><div className="mb-4 flex items-center justify-between"><div><p className="eyebrow mb-2">AVALIAÇÕES E REVISÕES</p><h2 className="font-display text-lg font-semibold text-slate-100">Histórico de aprendizagem</h2></div><Clock3 size={17} className="text-violet-300" /></div><div className="mb-4 grid grid-cols-2 gap-3"><div className="rounded-lg bg-[#121620] p-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Avaliações</p><strong className="mt-1 block font-display text-xl text-slate-100">{attempts.length}</strong></div><div className="rounded-lg bg-[#121620] p-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Revisões pendentes</p><strong className="mt-1 block font-display text-xl text-slate-100">{pendingReviewCount}</strong></div></div>{attempts.length ? <div className="space-y-2">{attempts.slice(0, 5).map((attempt) => <div key={attempt.id} className="flex items-center justify-between gap-3 rounded-lg border border-[#292e3b] bg-[#141821] px-3 py-2.5 text-xs"><span className="min-w-0 truncate text-slate-400">{attempt.skillName} · {attempt.mode === 'diagnostic' ? 'Diagnóstico' : attempt.mode === 'practice' ? 'Prática' : 'Domínio'}</span><span className={attempt.passed ? 'shrink-0 text-emerald-300' : 'shrink-0 text-slate-400'}>{attempt.scorePercent}% · {niceDate(attempt.createdAt)}</span></div>)}</div> : <p className="text-sm text-slate-500">Nenhuma avaliação registrada.</p>}<p className="mt-4 text-[11px] text-slate-600">{completedReviews.length} revisão{completedReviews.length === 1 ? '' : 'ões'} concluída{completedReviews.length === 1 ? '' : 's'} até agora.</p></article>
    </section>
    <section className="panel mt-5 flex flex-wrap items-center justify-between gap-4 border-rose-950/40 p-5"><div><p className="text-sm font-semibold text-slate-200">Recomeçar do início</p><p className="mt-1 text-xs text-slate-500">Apaga conquistas, experiência, missões e revisões deste dispositivo.</p></div><button className="action-secondary action-danger" onClick={reset} data-testid="button-reset-progress"><RotateCcw size={14} />Redefinir progresso</button></section>
  </div>;
}

function Goal() {
  const { state, updateGoal } = useStudyQuest();
  const [form, setForm] = useState({ course: state.goal.course || '', discipline: state.goal.discipline || '', title: state.goal.title || '', description: state.goal.description || '' });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const setField = (key: keyof typeof form, value: string) => { setForm({ ...form, [key]: value }); setSaved(false); };
  const save = (e: FormEvent) => { e.preventDefault(); if (!form.course.trim() || !form.discipline.trim() || !form.title.trim()) { setError('Informe o curso, a disciplina e um nome para o objetivo.'); return; } setError(''); updateGoal({ course: form.course.trim(), discipline: form.discipline.trim(), title: form.title.trim(), description: form.description.trim() }); setSaved(true); };
  return <div className="main-content fade-in max-w-3xl"><Link href="/" className="mb-6 inline-flex items-center gap-2 text-xs text-slate-500 hover:text-slate-200" data-testid="link-back-dashboard"><ArrowLeft size={14} />Visão geral</Link><PageHeading overline="DIREÇÃO DA JORNADA" title="Objetivo acadêmico" description="Um objetivo claro transforma cada habilidade em um passo com propósito." />
    <form onSubmit={save} className="panel space-y-5 p-5 sm:p-7"><div className="grid gap-4 sm:grid-cols-2"><label className="block"><span className="mb-2 block text-xs font-semibold text-slate-400">Curso</span><input className="field" list="course-options" required value={form.course} onChange={(e) => setField('course', e.target.value)} placeholder="Ex.: Engenharia de Energias" data-testid="input-goal-course" /><datalist id="course-options"><option value="Engenharia de Energias" /><option value="Engenharia Civil" /><option value="Engenharia Elétrica" /></datalist></label><label className="block"><span className="mb-2 block text-xs font-semibold text-slate-400">Disciplina foco</span><input className="field" list="discipline-options" required value={form.discipline} onChange={(e) => setField('discipline', e.target.value)} placeholder="Ex.: Cálculo I" data-testid="input-goal-discipline" /><datalist id="discipline-options"><option value="Cálculo I" /></datalist></label></div>
      <label className="block"><span className="mb-2 block text-xs font-semibold text-slate-400">Seu objetivo <span className="text-rose-300">*</span></span><input className="field" required value={form.title} onChange={(e) => setField('title', e.target.value)} placeholder="Ex.: Chegar preparado para a primeira prova" data-testid="input-goal-title" /></label>
      <label className="block"><span className="mb-2 block text-xs font-semibold text-slate-400">Por que isso importa?</span><textarea className="field min-h-[110px] resize-y" value={form.description} onChange={(e) => setField('description', e.target.value)} placeholder="Escreva algumas palavras para lembrar o que está construindo." data-testid="input-goal-description" /></label>
      {error && <p role="alert" className="text-sm text-rose-300">{error}</p>}{saved && <p role="status" className="text-sm text-emerald-300">Objetivo atualizado.</p>}
      <div className="flex flex-wrap justify-end gap-3 border-t border-[#2a2f3c] pt-5"><Link href="/" className="action-secondary" data-testid="button-cancel-goal">Cancelar</Link><button type="submit" className="action-primary" data-testid="button-save-goal">Salvar objetivo <Check size={14} /></button></div>
    </form>
  </div>;
}
function NotFoundPage() {
  return <div className="main-content grid min-h-[60vh] place-items-center"><div className="empty-state max-w-md"><CircleHelp className="mx-auto mb-3 text-slate-500" /><h1 className="font-display text-xl font-semibold text-slate-100">Esta página não existe</h1><p className="mt-2 text-sm text-slate-500">O caminho pode ter mudado. Volte para sua jornada.</p><Link href="/" className="action-primary mt-5" data-testid="button-not-found-home"><ArrowLeft size={14} />Ir para o início</Link></div></div>;
}

function Router() {
  return <Shell><Switch>
    <Route path="/" component={Dashboard} />
    <Route path="/trilha" component={Trail} />
    <Route path="/habilidade/:skillId" component={SkillDetail} />
    <Route path="/estudo/:skillId" component={Lesson} />
    <Route path="/avaliacao/:skillId/:mode" component={Assessment} />
    <Route path="/missoes" component={Missions} />
    <Route path="/revisoes" component={Reviews} />
    <Route path="/perfil" component={Profile} />
    <Route path="/objetivo" component={Goal} />
    <Route component={NotFoundPage} />
  </Switch></Shell>;
}
function App() { return <StudyQuestProvider><Router /></StudyQuestProvider>; }
export default App;
