import type { Mission, Question, Skill } from "./types";

const q = (
  id: string,
  prompt: string,
  correct: string,
  explanation: string,
  options: [string, string, string, string],
): Question => ({
  id,
  prompt,
  options: options.map((text, index) => ({
    id: ["a", "b", "c", "d"][index],
    text,
  })),
  correctOptionId: correct,
  explanation,
});

const ready = (
  id: string,
  name: string,
  description: string,
  importance: string,
  category: string,
  prerequisites: string[],
  order: { x: number; y: number },
  difficulty: Skill["difficulty"],
  steps: Skill["lessonSteps"],
  questions: Question[],
): Skill => ({
  id,
  name,
  description,
  importance,
  subject: "Cálculo I",
  category,
  prerequisites,
  order,
  difficulty,
  xp: 10,
  contentStatus: "ready",
  lessonSteps: steps,
  questions,
});

const planned = (
  id: string,
  name: string,
  description: string,
  category: string,
  prerequisites: string[],
  order: { x: number; y: number },
  difficulty: Skill["difficulty"],
): Skill => ({
  id,
  name,
  description,
  importance: "Este conteúdo faz parte da trilha ilustrativa e terá material completo em uma próxima versão.",
  subject: "Cálculo I",
  category,
  prerequisites,
  order,
  difficulty,
  xp: 10,
  contentStatus: "planned",
  lessonSteps: [],
  questions: [],
});

export const skills: Skill[] = [
  ready(
    "operations",
    "Operações aritméticas",
    "Ordem das operações, números inteiros e propriedades básicas.",
    "A base para calcular expressões sem perder a ordem ou o sinal.",
    "Fundamentos",
    [],
    { x: 0, y: 0 },
    1,
    [
      { id: "operations-order", title: "Ordem das operações", body: "Resolva primeiro o que está entre parênteses. Depois, potências e raízes; em seguida multiplicações e divisões, da esquerda para a direita; por fim adições e subtrações, também da esquerda para a direita.", example: "Em 8 − 2 × 3, faça primeiro 2 × 3 = 6. Então 8 − 6 = 2." },
      { id: "operations-signs", title: "Sinais e propriedades", body: "Somar um número negativo equivale a subtrair. Multiplicar ou dividir números com sinais iguais produz resultado positivo; sinais diferentes produzem resultado negativo.", example: "(−4) × 3 = −12, enquanto (−4) × (−3) = 12." },
    ],
    [
      q("op-1", "Qual é o valor de 8 − 2 × 3?", "b", "A multiplicação vem antes da subtração: 8 − 6 = 2.", ["18", "2", "6", "−6"]),
      q("op-2", "Quanto é (−5) + 8?", "c", "Partindo de −5 e avançando 8 unidades, chegamos a 3.", ["−13", "13", "3", "−3"]),
      q("op-3", "Qual é o resultado de (−4) × (−2)?", "a", "O produto de dois números negativos é positivo: 4 × 2 = 8.", ["8", "−8", "6", "−6"]),
      q("op-4", "Quanto é 24 ÷ 6 + 2?", "d", "Faça a divisão primeiro: 24 ÷ 6 = 4; depois 4 + 2 = 6.", ["3", "8", "12", "6"]),
      q("op-5", "Qual expressão vale 1?", "b", "Em 3 + 2 × (−1), a multiplicação dá −2; então 3 − 2 = 1.", ["(3 + 2) × −1", "3 + 2 × (−1)", "3 × 2 − 1", "3 − 2 × (−1)"]),
    ],
  ),
  ready(
    "fractions",
    "Frações e números racionais",
    "Equivalência, simplificação e operações com frações.",
    "Frações aparecem em funções, taxas de variação, limites e cálculos algébricos.",
    "Fundamentos",
    ["operations"],
    { x: 1, y: -1 },
    1,
    [
      { id: "fractions-meaning", title: "O que uma fração representa", body: "Uma fração a/b representa a divisão de a por b, com b diferente de zero. O numerador conta partes consideradas; o denominador indica em quantas partes iguais a unidade foi dividida.", example: "3/4 significa três partes quando a unidade foi dividida em quatro partes iguais." },
      { id: "fractions-equivalent", title: "Frações equivalentes", body: "Multiplicar ou dividir o numerador e o denominador pelo mesmo número diferente de zero mantém o valor da fração. Para somar frações, primeiro escreva-as com denominadores iguais.", example: "1/2 = 2/4. Para 1/3 + 1/6, use denominador 6: 2/6 + 1/6 = 3/6 = 1/2." },
      { id: "fractions-operations", title: "Multiplicação e divisão", body: "Na multiplicação, multiplique numeradores entre si e denominadores entre si. Na divisão por uma fração não nula, multiplique pela fração inversa.", example: "2/3 ÷ 4/5 = 2/3 × 5/4 = 10/12 = 5/6." },
    ],
    [
      q("fr-1", "Quanto é 1/3 + 1/6?", "a", "O denominador comum é 6: 1/3 = 2/6; então 2/6 + 1/6 = 1/2.", ["1/2", "2/9", "1/9", "2/3"]),
      q("fr-2", "Qual fração é equivalente a 3/4?", "c", "Multiplicando numerador e denominador por 2, obtemos 6/8.", ["6/10", "9/16", "6/8", "4/3"]),
      q("fr-3", "Quanto é 2/5 × 3/4?", "b", "Multiplique: (2 × 3)/(5 × 4) = 6/20 = 3/10.", ["5/9", "3/10", "6/9", "5/20"]),
      q("fr-4", "Quanto é 3/4 ÷ 1/2?", "d", "Dividir por 1/2 é multiplicar por 2: 3/4 × 2 = 6/4 = 3/2.", ["3/8", "1/4", "2/3", "3/2"]),
      q("fr-5", "Qual é a forma simplificada de 18/24?", "a", "O máximo divisor comum é 6. Dividindo ambos por 6, obtemos 3/4.", ["3/4", "6/8", "9/12", "2/3"]),
    ],
  ),
  ready(
    "powers",
    "Potências e raízes",
    "Regras de expoentes, potências de base negativa e raízes.",
    "As regras de expoentes simplificam expressões e são essenciais para funções polinomiais, exponenciais e limites.",
    "Fundamentos",
    ["operations", "fractions"],
    { x: 1, y: 1 },
    2,
    [
      { id: "powers-meaning", title: "Potência como multiplicação", body: "Para expoente natural n, a potência aⁿ representa o produto de n fatores iguais a a. A base pode ser negativa, mas os parênteses determinam o que está elevado.", example: "(−2)³ = (−2)(−2)(−2) = −8; já −2² = −(2²) = −4." },
      { id: "powers-laws", title: "Propriedades dos expoentes", body: "Na mesma base, aᵐ · aⁿ = aᵐ⁺ⁿ e aᵐ/aⁿ = aᵐ⁻ⁿ (a ≠ 0). Potência de potência: (aᵐ)ⁿ = aᵐⁿ. Expoente negativo indica inverso: a⁻ⁿ = 1/aⁿ.", example: "x³ · x² = x⁵. E 2⁻³ = 1/2³ = 1/8." },
      { id: "powers-roots", title: "Raízes e expoentes fracionários", body: "A raiz n-ésima desfaz a potência de expoente n quando definida nos reais. Expoentes fracionários representam raízes: a^(1/2) = √a para a ≥ 0.", example: "√49 = 7, pois 7² = 49." },
    ],
    [
      q("pw-1", "Quanto é 2³ × 2²?", "c", "Com a mesma base, some os expoentes: 2⁵ = 32.", ["2⁶", "2", "32", "64"]),
      q("pw-2", "Quanto é (−3)²?", "d", "O parêntese inclui o sinal na base: (−3)(−3) = 9.", ["−9", "−6", "6", "9"]),
      q("pw-3", "Como se escreve x⁻², para x ≠ 0?", "a", "Expoente negativo representa o inverso: x⁻² = 1/x².", ["1/x²", "−x²", "−1/x²", "x²"]),
      q("pw-4", "Qual é o valor de √81?", "b", "A raiz quadrada principal é o número não negativo cujo quadrado é 81: 9.", ["−9", "9", "40,5", "8"]),
      q("pw-5", "Quanto é (a³)²?", "c", "Em potência de potência, multiplique os expoentes: a^(3×2) = a⁶.", ["a⁵", "a⁹", "a⁶", "2a³"]),
    ],
  ),
  ready(
    "algebra",
    "Expressões algébricas",
    "Variáveis, termos semelhantes e simplificação de expressões.",
    "A linguagem algébrica permite representar relações gerais e preparar o estudo de equações e funções.",
    "Álgebra",
    ["operations", "fractions"],
    { x: 2, y: -1 },
    2,
    [
      { id: "algebra-terms", title: "Termos e variáveis", body: "Uma variável representa um valor que pode mudar. Em 3x + 2, o termo 3x tem coeficiente 3 e variável x; 2 é um termo constante.", example: "Se x = 4, então 3x + 2 = 3 · 4 + 2 = 14." },
      { id: "algebra-like-terms", title: "Termos semelhantes", body: "Só podemos somar diretamente termos com a mesma parte variável e os mesmos expoentes. Some ou subtraia apenas os coeficientes.", example: "5x + 2x − 3 = 7x − 3; x e x² não são termos semelhantes." },
    ],
    [
      q("al-1", "Simplifique 3x + 2x.", "b", "Os termos são semelhantes; some os coeficientes: 3x + 2x = 5x.", ["5", "5x", "6x", "x⁵"]),
      q("al-2", "Se x = 3, qual é o valor de 2x + 4?", "d", "Substituindo x por 3: 2 · 3 + 4 = 10.", ["9", "14", "8", "10"]),
      q("al-3", "Qual par é formado por termos semelhantes?", "a", "7a e −2a têm a mesma variável com o mesmo expoente.", ["7a e −2a", "x e x²", "3ab e 3a", "y e 1/y"]),
      q("al-4", "Desenvolva 2(x + 3).", "c", "A propriedade distributiva multiplica 2 por cada termo: 2x + 6.", ["2x + 3", "x + 6", "2x + 6", "5x"]),
      q("al-5", "Simplifique 4y − y + 2.", "d", "4y − y = 3y; o termo constante permanece: 3y + 2.", ["3", "5y + 2", "4y + 1", "3y + 2"]),
    ],
  ),
  ready(
    "equations",
    "Equações e inequações",
    "Resolução de equações lineares e leitura de desigualdades.",
    "Equações aparecem ao encontrar zeros de funções, modelar problemas e determinar pontos críticos.",
    "Álgebra",
    ["algebra", "fractions"],
    { x: 2, y: 1 },
    2,
    [
      { id: "equations-balance", title: "A equação como igualdade", body: "Uma equação afirma que duas expressões têm o mesmo valor. Para preservar a igualdade, faça a mesma operação nos dois lados.", example: "De x + 5 = 12, subtraia 5 dos dois lados: x = 7." },
      { id: "equations-linear", title: "Equações lineares", body: "Simplifique cada lado, reúna os termos com incógnita em um lado e os termos constantes no outro. Ao final, substitua o resultado na equação original para conferir.", example: "3x − 4 = 11 → 3x = 15 → x = 5. Conferindo: 15 − 4 = 11." },
      { id: "inequalities", title: "Inequações", body: "Em uma desigualdade, somar/subtrair o mesmo valor ou multiplicar por um positivo preserva o sentido. Ao multiplicar ou dividir por um número negativo, inverta o sinal.", example: "−2x < 6. Dividindo por −2 e invertendo <, obtemos x > −3." },
    ],
    [
      q("eq-1", "Resolva x + 5 = 12.", "a", "Subtraindo 5 dos dois lados, x = 12 − 5 = 7.", ["7", "17", "−7", "2,4"]),
      q("eq-2", "Resolva 3x − 4 = 11.", "c", "Some 4: 3x = 15. Divida por 3: x = 5.", ["3", "15", "5", "7"]),
      q("eq-3", "Resolva 2(x + 1) = 10.", "b", "Divida por 2: x + 1 = 5; subtraia 1: x = 4.", ["6", "4", "3", "5"]),
      q("eq-4", "Resolva −2x < 6.", "d", "Ao dividir ambos os lados por −2, inverta o sentido: x > −3.", ["x < −3", "x < 3", "x > 3", "x > −3"]),
      q("eq-5", "Qual valor satisfaz 5x + 2 = 17?", "a", "Subtraia 2: 5x = 15; dividindo por 5, x = 3.", ["3", "5", "15", "2"]),
    ],
  ),
  planned("factoring", "Produtos notáveis e fatoração", "Identidades algébricas e decomposição em fatores.", "Álgebra", ["algebra", "powers"], { x: 3, y: 0 }, 3),
  planned("coordinates", "Plano cartesiano", "Pontos, coordenadas e distância no plano.", "Geometria analítica", ["fractions"], { x: 3, y: 1 }, 2),
  ready(
    "functions",
    "Conceito de função",
    "Relação entre entradas e saídas, notação funcional e avaliação.",
    "Funções são o objeto central do Cálculo: limites, continuidade e derivadas descrevem como elas se comportam.",
    "Funções",
    ["equations", "coordinates"],
    { x: 4, y: 0 },
    2,
    [
      { id: "functions-definition", title: "O que é uma função", body: "Uma função associa a cada entrada permitida exatamente uma saída. O domínio reúne as entradas válidas; a imagem contém as saídas que a função realmente produz.", example: "Em f(x) = 2x + 1, cada número real x tem uma única saída." },
      { id: "functions-notation", title: "Notação e avaliação", body: "f(x) é o valor da função f na entrada x, não uma multiplicação entre f e x. Para calcular f(a), substitua cada ocorrência de x por a, usando parênteses se necessário.", example: "Se f(x) = x² − 1, então f(3) = 3² − 1 = 8." },
      { id: "functions-tests", title: "Como identificar uma função", body: "Uma relação é função quando cada entrada possui exatamente uma saída. Um mesmo valor de saída pode corresponder a várias entradas.", example: "A relação {(1, 2), (1, 3)} não é função: a entrada 1 tem duas saídas. {(1, 2), (2, 2)} é função." },
    ],
    [
      q("fu-1", "Se f(x) = 2x + 1, quanto vale f(3)?", "b", "Substitua x por 3: f(3) = 2 · 3 + 1 = 7.", ["6", "7", "5", "4"]),
      q("fu-2", "Qual relação não representa uma função?", "d", "A entrada 1 está associada a duas saídas diferentes, 2 e 3.", ["{(1,2),(2,2)}", "{(0,1),(1,2)}", "{(2,5),(3,5)}", "{(1,2),(1,3)}"]),
      q("fu-3", "Se g(x) = x² − 4, quanto vale g(−2)?", "a", "g(−2) = (−2)² − 4 = 4 − 4 = 0.", ["0", "−8", "8", "−4"]),
      q("fu-4", "Em uma função, o domínio representa:", "c", "O domínio é o conjunto das entradas para as quais a função está definida.", ["todas as saídas possíveis", "somente os zeros", "as entradas permitidas", "o maior valor da função"]),
      q("fu-5", "Se f(x) = x + 4, qual entrada produz saída 10?", "b", "Resolva x + 4 = 10, portanto x = 6.", ["14", "6", "4", "2,5"]),
    ],
  ),
  planned("domain-range", "Domínio e imagem", "Restrições de domínio e conjuntos de valores produzidos.", "Funções", ["functions", "fractions", "powers"], { x: 5, y: -1 }, 3),
  planned("linear-quadratic", "Funções afins e quadráticas", "Modelos lineares, parábolas e seus parâmetros.", "Funções", ["functions", "equations", "powers"], { x: 5, y: 1 }, 3),
  planned("polynomial-rational", "Funções polinomiais e racionais", "Polinômios, quocientes e comportamento algébrico.", "Funções", ["domain-range", "factoring"], { x: 6, y: 0 }, 3),
  planned("exponential-log", "Funções exponenciais e logarítmicas", "Crescimento exponencial e relação inversa logarítmica.", "Funções", ["powers", "functions"], { x: 6, y: 2 }, 4),
  planned("trigonometry", "Trigonometria básica", "Ângulos, razões trigonométricas e círculo trigonométrico.", "Trigonometria", ["fractions", "coordinates"], { x: 4, y: 2 }, 3),
  planned("graphs", "Leitura e interpretação de gráficos", "Interpretação de comportamento, interseções e variação visual.", "Funções", ["coordinates", "functions"], { x: 7, y: -1 }, 2),
  ready(
    "limits",
    "Introdução a limites",
    "A ideia de aproximação, limites laterais e cálculo de limites simples.",
    "O limite descreve o comportamento de uma função perto de um ponto e fundamenta derivadas e continuidade.",
    "Cálculo",
    ["domain-range", "linear-quadratic", "graphs"],
    { x: 8, y: 0 },
    3,
    [
      { id: "limits-idea", title: "A ideia de aproximação", body: "O limite de f(x) quando x tende a a descreve o valor ao qual f(x) se aproxima quando x fica perto de a. Isso não exige que f(a) exista nem que seja igual ao limite.", example: "Para f(x) = (x² − 1)/(x − 1), f(1) não está definida, mas para x ≠ 1 a expressão é x + 1; ao aproximar x de 1, o valor se aproxima de 2." },
      { id: "limits-substitution", title: "Substituição direta", body: "Se a função é contínua no ponto e a expressão está definida, substituir o valor de x normalmente calcula o limite. Se surgir indeterminação como 0/0, simplifique ou use outra estratégia antes de concluir.", example: "lim(x→2) (3x + 1) = 3 · 2 + 1 = 7." },
      { id: "limits-factor", title: "Simplificação por fatoração", body: "Uma forma 0/0 não é o resultado do limite. Ela indica que a expressão precisa ser reescrita. Fatore numerador e denominador e cancele apenas fatores comuns quando x é diferente do ponto.", example: "lim(x→1) (x² − 1)/(x − 1) = lim(x→1) (x − 1)(x + 1)/(x − 1) = 2." },
    ],
    [
      q("li-1", "Quanto é lim(x→2) (3x + 1)?", "c", "A expressão é contínua; substitua x = 2: 3 · 2 + 1 = 7.", ["5", "6", "7", "8"]),
      q("li-2", "Para f(x) = (x² − 1)/(x − 1), qual é lim(x→1) f(x)?", "a", "Fatore x² − 1 = (x − 1)(x + 1). Para x ≠ 1, a expressão é x + 1, que tende a 2.", ["2", "0", "1", "não existe porque f(1) não está definida"]),
      q("li-3", "O que significa obter 0/0 ao substituir em um limite?", "d", "0/0 é uma forma indeterminada; é necessário investigar a expressão, não concluir que o limite vale zero.", ["que o limite é zero", "que o limite não existe", "que o limite é infinito", "que a forma é indeterminada e requer análise"]),
      q("li-4", "Qual é lim(x→3) (x² + 2)?", "b", "A função polinomial é contínua; substituindo x = 3, temos 9 + 2 = 11.", ["9", "11", "5", "13"]),
      q("li-5", "Em um limite, a expressão f(a) precisa estar definida?", "c", "O limite depende do comportamento próximo a a, não necessariamente do valor da função exatamente em a.", ["sim, sempre", "sim, e deve ser igual ao limite", "não", "somente se a for zero"]),
    ],
  ),
  planned("continuity", "Continuidade", "Continuidade em um ponto e em intervalos.", "Cálculo", ["limits"], { x: 9, y: -1 }, 3),
  planned("derivatives", "Derivadas", "Taxa de variação instantânea e regras iniciais de derivação.", "Cálculo", ["limits", "linear-quadratic", "polynomial-rational"], { x: 9, y: 1 }, 4),
  planned("derivative-apps", "Aplicações básicas de derivadas", "Interpretação de crescimento, extremos e problemas de otimização.", "Cálculo", ["derivatives"], { x: 10, y: 0 }, 4),
  planned("integrals", "Introdução a integrais", "Área acumulada e antiderivadas em nível introdutório.", "Cálculo", ["derivatives", "functions"], { x: 10, y: 2 }, 5),
];

export const getSkill = (id: string) => skills.find((skill) => skill.id === id);

export const missions: Mission[] = [
  { id: "mission-first-lesson", title: "Primeira etapa", description: "Conclua uma etapa de qualquer lição disponível.", skillId: "operations", type: "lesson", rewardXp: 15, criterion: "Concluir pelo menos uma etapa de lição." },
  { id: "mission-fractions-mastery", title: "Domínio das frações", description: "Demonstre domínio em Frações e números racionais.", skillId: "fractions", type: "mastery", rewardXp: 15, criterion: "Aprovar o teste de domínio de Frações." },
  { id: "mission-powers-lesson", title: "Leis dos expoentes", description: "Conclua todas as etapas da lição de Potências e raízes.", skillId: "powers", type: "lesson", rewardXp: 15, criterion: "Concluir todas as etapas da lição." },
  { id: "mission-equation-practice", title: "Equilíbrio algébrico", description: "Complete uma avaliação de prática em Equações e inequações.", skillId: "equations", type: "practice", rewardXp: 15, criterion: "Enviar uma avaliação de prática." },
  { id: "mission-function-mastery", title: "Entender funções", description: "Demonstre domínio no conceito de função.", skillId: "functions", type: "mastery", rewardXp: 15, criterion: "Aprovar o teste de domínio de Funções." },
  { id: "mission-limit-review", title: "Manter o cálculo fresco", description: "Conclua uma revisão programada de Introdução a limites.", skillId: "limits", type: "review", rewardXp: 15, criterion: "Concluir com sucesso uma revisão de Limites." },
];

export function validateCatalogGraph(items: Skill[] = skills): boolean {
  const ids = new Set(items.map((skill) => skill.id));
  if (ids.size !== items.length) return false;
  for (const skill of items) {
    if (skill.prerequisites.some((id) => !ids.has(id) || id === skill.id)) return false;
  }
  const visiting = new Set<string>();
  const visited = new Set<string>();
  const byId = new Map(items.map((skill) => [skill.id, skill]));
  const visit = (id: string): boolean => {
    if (visiting.has(id)) return false;
    if (visited.has(id)) return true;
    visiting.add(id);
    const node = byId.get(id);
    if (!node) return false;
    for (const dependency of node.prerequisites) {
      if (!visit(dependency)) return false;
    }
    visiting.delete(id);
    visited.add(id);
    return true;
  };
  return items.every((skill) => visit(skill.id));
}
