import assert from "node:assert/strict";
import test from "node:test";
import { getSkill, skills, validateCatalogGraph } from "./catalog.ts";
import {
  completeLessonStep,
  completeMission,
  completeReview,
  createInitialState,
  getLevelProgress,
  getSkillStatus,
  hasNoCatalogCycles,
  scoreAssessment,
  submitAssessment,
  XP_REWARDS,
} from "./engine.ts";
import { exportBackup, isValidStudyQuestState, loadState, parseBackup, STORAGE_KEY } from "./storage.ts";
import type { Skill, StudyQuestState } from "./types.ts";

const fixedDate = new Date("2026-10-21T12:00:00.000Z");

function allAnswers(skillId: string, correct = true): Record<string, string> {
  const skill = getSkill(skillId);
  assert.ok(skill);
  return Object.fromEntries(
    skill.questions.map((question) => [
      question.id,
      correct ? question.correctOptionId : question.options[0].id,
    ]),
  );
}

function masterSkill(state: StudyQuestState, skillId: string): StudyQuestState {
  const skill = getSkill(skillId);
  assert.ok(skill);
  const answers = allAnswers(skillId);
  const result = submitAssessment(state, skillId, "mastery", answers, fixedDate);
  assert.ok(result.attempt?.passed);
  return result.state;
}

test("XP level thresholds match the documented progression", () => {
  assert.equal(getLevelProgress(0).level, 1);
  assert.equal(getLevelProgress(99).level, 1);
  assert.equal(getLevelProgress(100).level, 2);
  assert.equal(getLevelProgress(299).level, 2);
  assert.equal(getLevelProgress(300).level, 3);
  assert.equal(getLevelProgress(600).level, 4);
});

test("repeating a lesson step does not grant its XP twice", () => {
  const skill = getSkill("operations");
  assert.ok(skill);
  const empty = createInitialState();
  const once = completeLessonStep(empty, skill.id, skill.lessonSteps[0].id, fixedDate);
  const twice = completeLessonStep(once, skill.id, skill.lessonSteps[0].id, fixedDate);
  assert.equal(once.student.totalXp, XP_REWARDS.lessonStep);
  assert.equal(twice.student.totalXp, XP_REWARDS.lessonStep);
  assert.equal(twice.activity.filter((event) => event.id.startsWith("lesson-step:")).length, 1);
});

test("a skill remains locked until every prerequisite is mastered", () => {
  let state = createInitialState();
  assert.equal(getSkillStatus("fractions", state, fixedDate), "locked");
  state = masterSkill(state, "operations");
  assert.equal(getSkillStatus("fractions", state, fixedDate), "available");
  assert.equal(getSkillStatus("powers", state, fixedDate), "locked");
  state = masterSkill(state, "fractions");
  assert.equal(getSkillStatus("powers", state, fixedDate), "available");
});

test("XP alone cannot unlock a skill", () => {
  const state = createInitialState();
  const highXp = { ...state, student: { ...state.student, totalXp: 5000 } };
  assert.equal(getSkillStatus("fractions", highXp, fixedDate), "locked");
});

test("assessment scoring computes correct count and the 80 percent threshold", () => {
  const skill = getSkill("fractions");
  assert.ok(skill);
  const answers = allAnswers("fractions");
  answers[skill.questions[0].id] = skill.questions[0].options.find(
    (option) => option.id !== skill.questions[0].correctOptionId,
  )!.id;
  const score = scoreAssessment(skill, answers);
  assert.equal(score.correct, 4);
  assert.equal(score.total, 5);
  assert.equal(score.scorePercent, 80);
  assert.equal(score.passed, true);
});

test("mastery is recorded only after a passing assessment", () => {
  const skill = getSkill("operations");
  assert.ok(skill);
  let answers = allAnswers(skill.id);
  for (const question of skill.questions.slice(0, 2)) {
    answers[question.id] = question.options.find(
      (option) => option.id !== question.correctOptionId,
    )!.id;
  }
  const failed = submitAssessment(createInitialState(), skill.id, "mastery", answers, fixedDate);
  assert.equal(failed.attempt?.passed, false);
  assert.notEqual(failed.state.skillProgress[skill.id]?.status, "mastered");
  const passed = submitAssessment(
    failed.state,
    skill.id,
    "mastery",
    allAnswers(skill.id),
    new Date("2026-10-21T12:01:00.000Z"),
  );
  assert.equal(passed.attempt?.passed, true);
  assert.equal(passed.state.skillProgress[skill.id]?.status, "mastered");
});

test("practice rewards are idempotent while attempts remain in history", () => {
  const skill = getSkill("operations");
  assert.ok(skill);
  const first = submitAssessment(
    createInitialState(),
    skill.id,
    "practice",
    allAnswers(skill.id),
    fixedDate,
  );
  assert.ok(first.attempt);
  const second = submitAssessment(
    first.state,
    skill.id,
    "practice",
    allAnswers(skill.id),
    new Date("2026-10-21T12:01:00.000Z"),
  );
  assert.equal(second.state.student.totalXp, XP_REWARDS.practiceSet);
  assert.equal(second.state.skillProgress[skill.id].attempts.length, 2);
});

test("passing mastery schedules a review and a due review schedules the next interval", () => {
  const mastered = masterSkill(createInitialState(), "operations");
  assert.equal(mastered.reviewSchedule.length, 1);
  assert.equal(mastered.reviewSchedule[0].intervalDays, 1);
  const nextDay = new Date("2026-10-22T12:00:00.000Z");
  assert.equal(getSkillStatus("operations", mastered, nextDay), "review-due");
  const practice = submitAssessment(
    mastered,
    "operations",
    "practice",
    allAnswers("operations"),
    nextDay,
  );
  const reviewed = completeReview(
    practice.state,
    practice.state.reviewSchedule[0].id,
    true,
    nextDay,
  );
  assert.equal(reviewed.reviewSchedule[0].passed, true);
  assert.equal(reviewed.reviewSchedule[1].intervalDays, 3);
  assert.equal(reviewed.student.totalXp - practice.state.student.totalXp, XP_REWARDS.review);
  assert.equal(getSkillStatus("fractions", reviewed, nextDay), "available");
});

test("a passing review needs a fresh passing assessment; a failed review preserves mastery", () => {
  const mastered = masterSkill(createInitialState(), "operations");
  const nextDay = new Date("2026-10-22T12:00:00.000Z");
  const reviewId = mastered.reviewSchedule[0].id;
  assert.equal(completeReview(mastered, reviewId, true, nextDay), mastered);
  const failed = completeReview(mastered, reviewId, false, nextDay);
  assert.equal(failed.skillProgress.operations.status, "mastered");
  assert.equal(failed.reviewSchedule[0].passed, false);
  assert.equal(failed.reviewSchedule[1].dueAt, "2026-10-23T12:00:00.000Z");
});

test("a mission cannot be claimed until its criterion is met and cannot pay twice", () => {
  let state = createInitialState();
  const missionId = "mission-first-lesson";
  assert.equal(completeMission(state, missionId, fixedDate), state);
  state = completeLessonStep(
    state,
    "operations",
    getSkill("operations")!.lessonSteps[0].id,
    fixedDate,
  );
  const claimed = completeMission(state, missionId, fixedDate);
  const repeated = completeMission(claimed, missionId, fixedDate);
  assert.ok(claimed.completedMissions.includes(missionId));
  assert.equal(repeated.student.totalXp, claimed.student.totalXp);
});

test("backup validation, serialization, and reloading preserve progress", () => {
  const state = completeLessonStep(
    createInitialState(),
    "operations",
    getSkill("operations")!.lessonSteps[0].id,
    fixedDate,
  );
  const backup = exportBackup(state);
  assert.equal(isValidStudyQuestState(JSON.parse(backup)), true);
  assert.deepEqual(parseBackup(backup), state);
  assert.throws(() => parseBackup("{broken"), /JSON válido/);
  assert.throws(() => parseBackup(JSON.stringify({ version: 99 })), /backup não é válido/);

  const memory = new Map<string, string>([[STORAGE_KEY, backup]]);
  const storage = {
    getItem: (key: string) => memory.get(key) ?? null,
    setItem: (key: string, value: string) => memory.set(key, value),
    removeItem: (key: string) => memory.delete(key),
  };
  const loaded = loadState(storage);
  assert.equal(loaded.error, null);
  assert.deepEqual(loaded.state, state);
  const corrupt = "{not-json";
  memory.set(STORAGE_KEY, corrupt);
  const recovered = loadState(storage);
  assert.ok(recovered.error);
  assert.equal(memory.get(STORAGE_KEY), corrupt);
  const forgedMastery = createInitialState();
  forgedMastery.skillProgress.operations = {
    status: "mastered",
    completedSteps: [],
    attempts: [],
    masteredAt: fixedDate.toISOString(),
  };
  assert.equal(isValidStudyQuestState(forgedMastery), false);
});

test("evaluation attempts are appended rather than replacing history", () => {
  const first = submitAssessment(
    createInitialState(),
    "operations",
    "diagnostic",
    allAnswers("operations"),
    fixedDate,
  );
  const second = submitAssessment(
    first.state,
    "operations",
    "practice",
    allAnswers("operations"),
    new Date(fixedDate.getTime() + 1000),
  );
  assert.equal(second.state.skillProgress.operations.attempts.length, 2);
  assert.deepEqual(
    second.state.skillProgress.operations.attempts.map((attempt) => attempt.mode),
    ["diagnostic", "practice"],
  );
});

test("the initial dependency graph is acyclic and cycles are rejected", () => {
  assert.equal(hasNoCatalogCycles(), true);
  const cyclic: Skill[] = skills.map((skill) => ({ ...skill, prerequisites: [...skill.prerequisites] }));
  cyclic[0].prerequisites = [cyclic[1].id];
  cyclic[1].prerequisites = [cyclic[0].id];
  assert.equal(validateCatalogGraph(cyclic), false);
});
