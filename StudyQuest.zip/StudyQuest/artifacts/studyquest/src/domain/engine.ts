import { getSkill, missions, skills, validateCatalogGraph } from "./catalog.ts";
import type {
  ActivityEvent,
  AssessmentAttempt,
  AssessmentMode,
  Goal,
  LevelProgress,
  Mission,
  ReviewEntry,
  Skill,
  SkillProgress,
  SkillStatus,
  StudyQuestState,
} from "./types.ts";

export const PASSING_SCORE_PERCENT = 80;
export const XP_REWARDS = {
  lessonStep: 10,
  mission: 15,
  practiceSet: 20,
  review: 15,
  mastery: 25,
} as const;
export const REVIEW_INTERVALS_DAYS = [1, 3, 7, 14, 30] as const;

export const DEFAULT_GOAL: Goal = {
  course: "Engenharia de Energias",
  discipline: "Cálculo I",
  title: "Preparar-me para Cálculo I",
  description: "",
};

export function createInitialState(): StudyQuestState {
  return {
    version: 1,
    student: { name: "Estudante", totalXp: 0 },
    goal: { ...DEFAULT_GOAL },
    skillProgress: {},
    activity: [],
    completedMissions: [],
    reviewSchedule: [],
  };
}

export function xpForLevel(level: number): number {
  const safeLevel = Math.max(1, Math.floor(level));
  return 50 * safeLevel * (safeLevel - 1);
}

export function getLevelProgress(totalXp: number): LevelProgress {
  const xp = Math.max(0, Math.floor(totalXp));
  let level = 1;
  while (xp >= xpForLevel(level + 1)) level += 1;
  const totalXpForNextLevel = xpForLevel(level + 1);
  const currentLevelStart = xpForLevel(level);
  const xpForNextLevel = totalXpForNextLevel - currentLevelStart;
  return {
    level,
    xpIntoLevel: xp - currentLevelStart,
    xpForNextLevel,
    totalXpForNextLevel,
    percentToNextLevel: Math.min(
      100,
      Math.round(((xp - currentLevelStart) / xpForNextLevel) * 100),
    ),
  };
}

export function scoreAssessment(
  skill: Skill,
  answers: Record<string, string>,
): { correct: number; total: number; scorePercent: number; passed: boolean } {
  const total = skill.questions.length;
  const correct = skill.questions.reduce(
    (count, question) =>
      count + (answers[question.id] === question.correctOptionId ? 1 : 0),
    0,
  );
  const scorePercent = total > 0 ? Math.round((correct / total) * 100) : 0;
  return {
    correct,
    total,
    scorePercent,
    passed: total > 0 && scorePercent >= PASSING_SCORE_PERCENT,
  };
}

export function getSkillStatus(
  skillId: string,
  state: StudyQuestState,
  now = new Date(),
): SkillStatus {
  const skill = getSkill(skillId);
  if (!skill) return "locked";
  const progress = state.skillProgress[skillId];
  if (progress?.status === "mastered") {
    const due = state.reviewSchedule.some(
      (review) =>
        review.skillId === skillId &&
        !review.completedAt &&
        new Date(review.dueAt).getTime() <= now.getTime(),
    );
    return due ? "review-due" : "mastered";
  }
  if (progress?.status === "learning") return "learning";
  const unlocked = skill.prerequisites.every(
    (id) => state.skillProgress[id]?.status === "mastered",
  );
  return unlocked ? "available" : "locked";
}

export function missingPrerequisites(
  skill: Skill,
  state: StudyQuestState,
): Skill[] {
  return skill.prerequisites
    .filter((id) => state.skillProgress[id]?.status !== "mastered")
    .map((id) => getSkill(id))
    .filter((item): item is Skill => Boolean(item));
}

export function getAvailableSkills(state: StudyQuestState): Skill[] {
  return skills.filter((skill) => {
    const status = getSkillStatus(skill.id, state);
    return (status === "available" || status === "learning") &&
      skill.contentStatus === "ready";
  });
}

export function hasNoCatalogCycles(): boolean {
  return validateCatalogGraph();
}

const dateAfterDays = (date: Date, days: number) =>
  new Date(date.getTime() + days * 24 * 60 * 60 * 1000).toISOString();

function addActivity(
  state: StudyQuestState,
  event: Omit<ActivityEvent, "createdAt">,
  now: Date,
): StudyQuestState {
  if (state.activity.some((item) => item.id === event.id)) return state;
  return {
    ...state,
    student: {
      ...state.student,
      totalXp: state.student.totalXp + Math.max(0, event.xp),
    },
    activity: [{ ...event, createdAt: now.toISOString() }, ...state.activity],
  };
}

function progressFor(state: StudyQuestState, skillId: string): SkillProgress {
  return state.skillProgress[skillId] ?? {
    status: "learning",
    completedSteps: [],
    attempts: [],
  };
}

export function startLesson(
  state: StudyQuestState,
  skillId: string,
): StudyQuestState {
  const skill = getSkill(skillId);
  if (!skill || skill.contentStatus !== "ready") return state;
  const status = getSkillStatus(skillId, state);
  if (status === "locked" || status === "mastered" || status === "review-due") {
    return state;
  }
  const current = progressFor(state, skillId);
  return {
    ...state,
    skillProgress: {
      ...state.skillProgress,
      [skillId]: { ...current, status: "learning" },
    },
  };
}

export function completeLessonStep(
  state: StudyQuestState,
  skillId: string,
  stepId: string,
  now = new Date(),
): StudyQuestState {
  const skill = getSkill(skillId);
  if (!skill || getSkillStatus(skillId, state, now) === "locked") return state;
  if (!skill.lessonSteps.some((step) => step.id === stepId)) return state;
  const current = progressFor(state, skillId);
  const alreadyCompleted = current.completedSteps.includes(stepId);
  const nextProgress: SkillProgress = {
    ...current,
    status: current.status === "mastered" ? "mastered" : "learning",
    completedSteps: alreadyCompleted
      ? current.completedSteps
      : [...current.completedSteps, stepId],
  };
  const withProgress = {
    ...state,
    skillProgress: { ...state.skillProgress, [skillId]: nextProgress },
  };
  if (alreadyCompleted) return withProgress;
  return addActivity(
    withProgress,
    {
      id: `lesson-step:${skillId}:${stepId}`,
      type: "lesson-step",
      title: "Etapa de lição concluída",
      description: `${skill.name}: etapa de estudo concluída.`,
      skillId,
      xp: XP_REWARDS.lessonStep,
    },
    now,
  );
}

function scheduleFirstReview(
  existing: ReviewEntry[],
  skillId: string,
  now: Date,
): ReviewEntry[] {
  const hasPending = existing.some(
    (review) => review.skillId === skillId && !review.completedAt,
  );
  if (hasPending) return existing;
  const dueAt = dateAfterDays(now, REVIEW_INTERVALS_DAYS[0]);
  const id = `review:${skillId}:1:${dueAt.slice(0, 10)}`;
  return [
    ...existing,
    { id, skillId, dueAt, intervalDays: REVIEW_INTERVALS_DAYS[0], sequence: 1 },
  ];
}

export function submitAssessment(
  state: StudyQuestState,
  skillId: string,
  mode: AssessmentMode,
  answers: Record<string, string>,
  now = new Date(),
): { state: StudyQuestState; attempt?: AssessmentAttempt } {
  const skill = getSkill(skillId);
  if (!skill || skill.contentStatus !== "ready" || skill.questions.length === 0) {
    return { state };
  }
  const status = getSkillStatus(skillId, state, now);
  if (status === "locked") return { state };
  if (
    skill.questions.some(
      (question) =>
        !answers[question.id] ||
        !question.options.some((option) => option.id === answers[question.id]),
    )
  ) {
    return { state };
  }
  if (
    mode === "mastery" &&
    status !== "available" &&
    status !== "learning"
  ) {
    return { state };
  }
  if (mode === "diagnostic" && status !== "available" && status !== "learning") {
    return { state };
  }
  if (mode === "practice" && status === "review-due") {
    // A due review remains available as a review and does not turn into a new mastery attempt.
  }
  const result = scoreAssessment(skill, answers);
  const attempt: AssessmentAttempt = {
    id: `attempt:${skillId}:${now.getTime()}:${state.skillProgress[skillId]?.attempts.length ?? 0}`,
    skillId,
    mode,
    answers: { ...answers },
    scorePercent: result.scorePercent,
    passed: result.passed,
    createdAt: now.toISOString(),
  };
  const current = progressFor(state, skillId);
  let nextProgress: SkillProgress = {
    ...current,
    attempts: [...current.attempts, attempt],
  };
  let nextState: StudyQuestState = {
    ...state,
    skillProgress: {
      ...state.skillProgress,
      [skillId]: nextProgress,
    },
  };
  nextState = addActivity(
    nextState,
    {
      id: `assessment:${attempt.id}`,
      type: "assessment",
      title:
        mode === "practice"
          ? "Lista de exercícios concluída"
          : mode === "diagnostic"
            ? "Diagnóstico concluído"
            : "Teste de domínio concluído",
      description: `${skill.name}: ${result.correct} de ${result.total} acertos (${result.scorePercent}%).`,
      skillId,
      xp: 0,
    },
    now,
  );
  if (mode === "practice" && !state.activity.some((event) => event.id === `practice:${skillId}`)) {
    nextState = addActivity(
      nextState,
      {
        id: `practice:${skillId}`,
        type: "assessment",
        title: "Recompensa de prática",
        description: `Primeira lista de exercícios concluída: ${skill.name}.`,
        skillId,
        xp: XP_REWARDS.practiceSet,
      },
      now,
    );
  }
  if (
    (mode === "mastery" || mode === "diagnostic") &&
    result.passed &&
    current.status !== "mastered"
  ) {
    nextProgress = {
      ...nextProgress,
      status: "mastered",
      masteredAt: now.toISOString(),
    };
    nextState = {
      ...nextState,
      skillProgress: {
        ...nextState.skillProgress,
        [skillId]: nextProgress,
      },
      reviewSchedule: scheduleFirstReview(
        nextState.reviewSchedule,
        skillId,
        now,
      ),
    };
    nextState = addActivity(
      nextState,
      {
        id: `mastery:${skillId}`,
        type: "mastery",
        title: "Habilidade dominada",
        description: `${skill.name} foi demonstrada com resultado de ${result.scorePercent}%.`,
        skillId,
        xp: XP_REWARDS.mastery,
      },
      now,
    );
  } else if (current.status !== "mastered") {
    nextProgress = { ...nextProgress, status: "learning" };
    nextState = {
      ...nextState,
      skillProgress: {
        ...nextState.skillProgress,
        [skillId]: nextProgress,
      },
    };
  }
  return { state: nextState, attempt };
}

export function canCompleteMission(
  mission: Mission,
  state: StudyQuestState,
): boolean {
  const progress = state.skillProgress[mission.skillId];
  if (!progress) return false;
  switch (mission.type) {
    case "lesson":
      return mission.id === "mission-first-lesson"
        ? progress.completedSteps.length > 0
        : getSkill(mission.skillId)?.lessonSteps.every((step) =>
            progress.completedSteps.includes(step.id),
          ) ?? false;
    case "practice":
      return progress.attempts.some((attempt) => attempt.mode === "practice");
    case "mastery":
      return progress.status === "mastered";
    case "review":
      return state.reviewSchedule.some(
        (review) => review.skillId === mission.skillId && review.completedAt && review.passed,
      );
  }
}

export function completeMission(
  state: StudyQuestState,
  missionId: string,
  now = new Date(),
): StudyQuestState {
  const mission = missions.find((item) => item.id === missionId);
  if (
    !mission ||
    state.completedMissions.includes(missionId) ||
    !canCompleteMission(mission, state)
  ) {
    return state;
  }
  const nextState = {
    ...state,
    completedMissions: [...state.completedMissions, missionId],
  };
  return addActivity(
    nextState,
    {
      id: `mission:${missionId}`,
      type: "mission",
      title: "Missão concluída",
      description: mission.title,
      skillId: mission.skillId,
      xp: mission.rewardXp,
    },
    now,
  );
}

export function completeReview(
  state: StudyQuestState,
  reviewId: string,
  passed: boolean,
  now = new Date(),
): StudyQuestState {
  const target = state.reviewSchedule.find((review) => review.id === reviewId);
  if (
    !target ||
    target.completedAt ||
    getSkillStatus(target.skillId, state, now) !== "review-due"
  ) {
    return state;
  }
  const skill = getSkill(target.skillId);
  if (!skill) return state;
  const reviewEvidence = state.skillProgress[target.skillId]?.attempts.some(
    (attempt) =>
      attempt.createdAt >= target.dueAt &&
      attempt.scorePercent >= PASSING_SCORE_PERCENT &&
      attempt.passed,
  );
  if (passed && !reviewEvidence) return state;
  let schedule = state.reviewSchedule.map((review) =>
    review.id === reviewId
      ? { ...review, completedAt: now.toISOString(), passed }
      : review,
  );
  if (passed) {
    const nextInterval = REVIEW_INTERVALS_DAYS[target.sequence];
    if (nextInterval) {
      const dueAt = dateAfterDays(now, nextInterval);
      schedule = [
        ...schedule,
        {
          id: `review:${target.skillId}:${target.sequence + 1}:${dueAt.slice(0, 10)}`,
          skillId: target.skillId,
          dueAt,
          intervalDays: nextInterval,
          sequence: target.sequence + 1,
        },
      ];
    }
  } else {
    const dueAt = dateAfterDays(now, 1);
    schedule = [
      ...schedule,
      {
        id: `review:${target.skillId}:retry:${now.getTime()}`,
        skillId: target.skillId,
        dueAt,
        intervalDays: 1,
        sequence: target.sequence,
      },
    ];
  }
  const nextState = { ...state, reviewSchedule: schedule };
  return passed
    ? addActivity(
        nextState,
        {
          id: `review-reward:${reviewId}`,
          type: "review",
          title: "Revisão concluída",
          description: `Você revisou ${skill.name} com sucesso.`,
          skillId: skill.id,
          xp: XP_REWARDS.review,
        },
        now,
      )
    : addActivity(
        nextState,
        {
          id: `review-failed:${reviewId}`,
          type: "review",
          title: "Revisão precisa de reforço",
          description: `A revisão de ${skill.name} foi registrada. Uma nova oportunidade será agendada para amanhã.`,
          skillId: skill.id,
          xp: 0,
        },
        now,
      );
}

export function updateGoal(
  state: StudyQuestState,
  goal: Goal,
  now = new Date(),
): StudyQuestState {
  const normalized = {
    course: goal.course.trim(),
    discipline: goal.discipline.trim(),
    title: goal.title.trim(),
    description: goal.description.trim(),
  };
  if (!normalized.course || !normalized.discipline || !normalized.title) return state;
  return {
    ...state,
    goal: normalized,
    activity: [
      {
        id: `goal:${now.getTime()}:${state.activity.filter((event) => event.type === "goal").length}`,
        type: "goal",
        title: "Objetivo acadêmico atualizado",
        description: normalized.title,
        xp: 0,
        createdAt: now.toISOString(),
      },
      ...state.activity,
    ],
  };
}

export function dueReviews(state: StudyQuestState, now = new Date()): ReviewEntry[] {
  return state.reviewSchedule.filter(
    (review) =>
      !review.completedAt && new Date(review.dueAt).getTime() <= now.getTime(),
  );
}

export function overallProgress(state: StudyQuestState): number {
  if (skills.length === 0) return 0;
  const mastered = skills.filter(
    (skill) => state.skillProgress[skill.id]?.status === "mastered",
  ).length;
  return Math.round((mastered / skills.length) * 100);
}
