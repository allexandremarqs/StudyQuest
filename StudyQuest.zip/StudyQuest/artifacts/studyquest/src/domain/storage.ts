import { createInitialState, scoreAssessment } from "./engine.ts";
import { missions, skills } from "./catalog.ts";
import type { StudyQuestState } from "./types.ts";

export const STORAGE_KEY = "studyquest:progress:v1";

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export function isValidStudyQuestState(value: unknown): value is StudyQuestState {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<StudyQuestState>;
  if (
    candidate.version !== 1 ||
    !candidate.student ||
    typeof candidate.student.name !== "string" ||
    !Number.isInteger(candidate.student.totalXp) ||
    candidate.student.totalXp < 0 ||
    !candidate.goal ||
    typeof candidate.goal.course !== "string" ||
    typeof candidate.goal.discipline !== "string" ||
    typeof candidate.goal.title !== "string" ||
    typeof candidate.goal.description !== "string" ||
    !candidate.skillProgress ||
    typeof candidate.skillProgress !== "object" ||
    !Array.isArray(candidate.activity) ||
    !Array.isArray(candidate.completedMissions) ||
    !Array.isArray(candidate.reviewSchedule)
  ) {
    return false;
  }
  const progressBySkill = candidate.skillProgress;
  const skillIds = new Set(skills.map((skill) => skill.id));
  for (const [skillId, progress] of Object.entries(progressBySkill)) {
    if (
      !skillIds.has(skillId) ||
      !progress ||
      !["learning", "mastered"].includes(progress.status) ||
      !Array.isArray(progress.completedSteps) ||
      new Set(progress.completedSteps).size !== progress.completedSteps.length ||
      !Array.isArray(progress.attempts) ||
      new Set(progress.attempts.map((attempt) => attempt.id)).size !== progress.attempts.length
    ) {
      return false;
    }
    const skill = skills.find((item) => item.id === skillId);
    if (!skill) return false;
    if (progress.completedSteps.some((id) => !skill.lessonSteps.some((step) => step.id === id))) {
      return false;
    }
    if (
      progress.attempts.some(
        (attempt) =>
          !attempt ||
          attempt.skillId !== skillId ||
          !["diagnostic", "practice", "mastery"].includes(attempt.mode) ||
          !Number.isFinite(attempt.scorePercent) ||
          attempt.scorePercent < 0 ||
          attempt.scorePercent > 100 ||
          typeof attempt.passed !== "boolean" ||
          typeof attempt.createdAt !== "string" ||
          !attempt.answers ||
          typeof attempt.answers !== "object",
      )
    ) {
      return false;
    }
    for (const attempt of progress.attempts) {
      const questionIds = new Set(skill.questions.map((question) => question.id));
      if (
        Object.keys(attempt.answers).length !== questionIds.size ||
        Object.entries(attempt.answers).some(
          ([questionId, optionId]) =>
            !questionIds.has(questionId) ||
            !skill.questions
              .find((question) => question.id === questionId)
              ?.options.some((option) => option.id === optionId),
        )
      ) {
        return false;
      }
      const score = scoreAssessment(skill, attempt.answers);
      if (
        attempt.scorePercent !== score.scorePercent ||
        attempt.passed !== score.passed ||
        !Number.isFinite(Date.parse(attempt.createdAt))
      ) {
        return false;
      }
    }
    if (progress.status === "mastered") {
      const hasEvidence = progress.attempts.some(
        (attempt) =>
          (attempt.mode === "diagnostic" || attempt.mode === "mastery") &&
          attempt.passed,
      );
      if (
        !hasEvidence ||
        !progress.masteredAt ||
        !Number.isFinite(Date.parse(progress.masteredAt))
      ) {
        return false;
      }
    }
  }
  for (const [skillId, progress] of Object.entries(progressBySkill)) {
    if (
      progress.status === "mastered" &&
      !skills
        .find((skill) => skill.id === skillId)!
        .prerequisites.every(
          (prerequisiteId) =>
            progressBySkill[prerequisiteId]?.status === "mastered",
        )
    ) {
      return false;
    }
  }
  if (
    candidate.activity.some(
      (event) =>
        !event ||
        typeof event.id !== "string" ||
        typeof event.title !== "string" ||
        typeof event.description !== "string" ||
        !Number.isInteger(event.xp) ||
        event.xp < 0 ||
        typeof event.createdAt !== "string" ||
        !Number.isFinite(Date.parse(event.createdAt)),
    ) ||
    new Set(candidate.activity.map((event) => event.id)).size !== candidate.activity.length ||
    candidate.activity.reduce((total, event) => total + event.xp, 0) !==
      candidate.student.totalXp ||
    candidate.completedMissions.some(
      (id) => typeof id !== "string" || !missions.some((mission) => mission.id === id),
    ) ||
    new Set(candidate.completedMissions).size !== candidate.completedMissions.length ||
    candidate.reviewSchedule.some(
      (review) =>
        !review ||
        typeof review.id !== "string" ||
        !skillIds.has(review.skillId) ||
        !Number.isFinite(review.intervalDays) ||
        !Number.isFinite(review.sequence) ||
        typeof review.dueAt !== "string" ||
        !Number.isFinite(Date.parse(review.dueAt)) ||
        (review.completedAt !== undefined && typeof review.completedAt !== "string") ||
        (review.completedAt !== undefined &&
          !Number.isFinite(Date.parse(review.completedAt))) ||
        (review.passed !== undefined && typeof review.passed !== "boolean"),
    )
  ) {
    return false;
  }
  if (
    new Set(candidate.reviewSchedule.map((review) => review.id)).size !==
    candidate.reviewSchedule.length
  ) {
    return false;
  }
  return true;
}

export function parseBackup(json: string): StudyQuestState {
  let parsed: unknown;
  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error("O arquivo não contém um JSON válido.");
  }
  if (!isValidStudyQuestState(parsed)) {
    throw new Error(
      "Este backup não é válido ou foi criado em uma versão incompatível do StudyQuest.",
    );
  }
  return parsed;
}

export function exportBackup(state: StudyQuestState): string {
  return JSON.stringify(state, null, 2);
}

export function loadState(
  storage: StorageLike | null,
): { state: StudyQuestState; error: string | null } {
  if (!storage) return { state: createInitialState(), error: null };
  try {
    const raw = storage.getItem(STORAGE_KEY);
    if (!raw) return { state: createInitialState(), error: null };
    const parsed: unknown = JSON.parse(raw);
    if (!isValidStudyQuestState(parsed)) {
      return {
        state: createInitialState(),
        error:
          "Os dados salvos não puderam ser reconhecidos. Seu progresso original foi preservado até você escolher recuperar ou reiniciar.",
      };
    }
    return { state: parsed, error: null };
  } catch {
    return {
      state: createInitialState(),
      error:
        "Não foi possível ler o progresso salvo neste navegador. Seu progresso original foi preservado até você escolher recuperar ou reiniciar.",
    };
  }
}

export function saveState(storage: StorageLike, state: StudyQuestState): void {
  storage.setItem(STORAGE_KEY, exportBackup(state));
}
