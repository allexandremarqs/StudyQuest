export type SkillStatus =
  | "locked"
  | "available"
  | "learning"
  | "mastered"
  | "review-due";

export type AssessmentMode = "diagnostic" | "practice" | "mastery";
export type InitialKnowledgeLevel =
  | "beginner"
  | "intermediate"
  | "advanced"
  | "diagnostic";

export interface Question {
  id: string;
  type?: "multiple-choice";
  prompt: string;
  options: { id: string; text: string }[];
  correctOptionId: string;
  explanation: string;
}

export interface LessonStep {
  id: string;
  title: string;
  body: string;
  example?: string;
  blocks?: LearningContentBlock[];
}

export type LearningContentBlock =
  | { type: "text"; content: string }
  | { type: "worked-example"; title: string; content: string };

export interface Skill {
  id: string;
  name: string;
  description: string;
  importance: string;
  competencies?: string[];
  subject: string;
  category: string;
  prerequisites: string[];
  order: { x: number; y: number };
  difficulty: 1 | 2 | 3 | 4 | 5;
  xp: number;
  masteryThresholdPercent?: number;
  contentStatus: "ready" | "planned";
  lessonSteps: LessonStep[];
  questions: Question[];
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  skillId: string;
  type: "lesson" | "practice" | "mastery" | "review";
  rewardXp: number;
  criterion: string;
}

export interface Goal {
  course: string;
  discipline: string;
  title: string;
  description: string;
}

export interface ObjectiveSkillRequirement {
  skillId: string;
  masteryThresholdPercent: number;
}

export interface LearningObjective {
  id: string;
  title: string;
  categoryId: string;
  categoryLabel: string;
  description: string;
  initialLevel: InitialKnowledgeLevel;
  source: "catalog" | "custom" | "legacy";
  templateId?: string;
  skillRequirements: ObjectiveSkillRequirement[];
  createdAt: string;
}

export interface LearningJourney {
  id: string;
  name: string;
  objectiveIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface ObjectiveDraft {
  title: string;
  categoryId: string;
  categoryLabel: string;
  description?: string;
  initialLevel: InitialKnowledgeLevel;
  source: "catalog" | "custom";
  templateId?: string;
  skillRequirements: ObjectiveSkillRequirement[];
}

export interface ObjectiveTemplate {
  id: string;
  title: string;
  categoryId: string;
  categoryLabel: string;
  description: string;
  skillRequirements: ObjectiveSkillRequirement[];
}

export interface AssessmentAttempt {
  id: string;
  skillId: string;
  mode: AssessmentMode;
  answers: Record<string, string>;
  scorePercent: number;
  requiredScorePercent?: number;
  passed: boolean;
  createdAt: string;
}

export interface SkillProgress {
  status: Exclude<SkillStatus, "locked" | "available" | "review-due">;
  completedSteps: string[];
  attempts: AssessmentAttempt[];
  masteredAt?: string;
  nextReviewAt?: string;
}

export interface ActivityEvent {
  id: string;
  type:
    | "lesson-step"
    | "assessment"
    | "mastery"
    | "mission"
    | "review"
    | "goal"
    | "journey"
    | "objective"
    | "skill-created";
  title: string;
  description: string;
  skillId?: string;
  xp: number;
  createdAt: string;
}

export interface ReviewEntry {
  id: string;
  skillId: string;
  dueAt: string;
  intervalDays: number;
  sequence: number;
  completedAt?: string;
  passed?: boolean;
}

export interface StudentState {
  name: string;
  totalXp: number;
}

export interface StudyQuestState {
  version: 2;
  student: StudentState;
  journeys: LearningJourney[];
  objectives: LearningObjective[];
  activeJourneyId: string | null;
  activeObjectiveId: string | null;
  customSkills: Skill[];
  skillProgress: Record<string, SkillProgress>;
  activity: ActivityEvent[];
  completedMissions: string[];
  reviewSchedule: ReviewEntry[];
}

export interface LegacyStudyQuestState {
  version: 1;
  student: StudentState;
  goal: Goal;
  skillProgress: Record<string, SkillProgress>;
  activity: ActivityEvent[];
  completedMissions: string[];
  reviewSchedule: ReviewEntry[];
}

export interface LevelProgress {
  level: number;
  xpIntoLevel: number;
  xpForNextLevel: number;
  totalXpForNextLevel: number;
  percentToNextLevel: number;
}
