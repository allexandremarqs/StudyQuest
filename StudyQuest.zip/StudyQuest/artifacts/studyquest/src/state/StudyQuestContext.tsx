import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  completeLessonStep as applyLessonStep,
  completeMission as applyMission,
  completeReview as applyReview,
  getSkillStatus,
  startLesson as applyStartLesson,
  submitAssessment as applyAssessment,
  updateGoal as applyGoal,
  createInitialState,
} from "@/domain/engine";
import { exportBackup, loadState, parseBackup, saveState } from "@/domain/storage";
import type {
  AssessmentAttempt,
  AssessmentMode,
  Goal,
  ReviewEntry,
  SkillStatus,
  StudyQuestState,
} from "@/domain/types";

interface StudyQuestContextValue {
  state: StudyQuestState;
  storageError: string | null;
  skillStatus(skillId: string): SkillStatus;
  startLesson(skillId: string): void;
  completeLessonStep(skillId: string, stepId: string): void;
  submitAssessment(
    skillId: string,
    mode: AssessmentMode,
    answerIds: Record<string, string>,
  ): AssessmentAttempt | undefined;
  completeMission(missionId: string): void;
  completeReview(skillId: string, reviewId: string, passed: boolean): boolean;
  updateGoal(goal: Goal): void;
  exportBackup(): string;
  importBackup(json: string): void;
  resetProgress(): void;
  recoverStorage(): void;
}

const StudyQuestContext = createContext<StudyQuestContextValue | null>(null);

function getBrowserStorage() {
  try {
    return typeof window === "undefined" ? null : window.localStorage;
  } catch {
    return null;
  }
}

export function StudyQuestProvider({ children }: { children: ReactNode }) {
  const [initial] = useState(() => loadState(getBrowserStorage()));
  const [state, setState] = useState(initial.state);
  const [storageError, setStorageError] = useState(initial.error);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (!dirty || storageError) return;
    const storage = getBrowserStorage();
    if (!storage) {
      setStorageError("O armazenamento local não está disponível neste navegador.");
      return;
    }
    try {
      saveState(storage, state);
    } catch {
      setStorageError(
        "Não foi possível salvar o progresso. Verifique o espaço disponível no navegador.",
      );
    }
  }, [dirty, state, storageError]);

  const update = useCallback((next: StudyQuestState) => {
    if (next !== state) {
      setState(next);
      setDirty(true);
    }
  }, [state]);

  const skillStatus = useCallback(
    (skillId: string) => getSkillStatus(skillId, state),
    [state],
  );

  const startLesson = useCallback(
    (skillId: string) => update(applyStartLesson(state, skillId)),
    [state, update],
  );

  const completeLessonStep = useCallback(
    (skillId: string, stepId: string) =>
      update(applyLessonStep(state, skillId, stepId)),
    [state, update],
  );

  const submitAssessment = useCallback(
    (skillId: string, mode: AssessmentMode, answerIds: Record<string, string>) => {
      const result = applyAssessment(state, skillId, mode, answerIds);
      if (result.attempt) update(result.state);
      return result.attempt;
    },
    [state, update],
  );

  const completeMission = useCallback(
    (missionId: string) => update(applyMission(state, missionId)),
    [state, update],
  );

  const completeReview = useCallback(
    (_skillId: string, reviewId: string, passed: boolean) => {
      const next = applyReview(state, reviewId, passed);
      if (next === state) return false;
      update(next);
      return true;
    },
    [state, update],
  );

  const updateGoal = useCallback(
    (goal: Goal) => update(applyGoal(state, goal)),
    [state, update],
  );

  const importStudentBackup = useCallback((json: string) => {
    const imported = parseBackup(json);
    setState(imported);
    setStorageError(null);
    setDirty(true);
  }, []);

  const resetProgress = useCallback(() => {
    setState(createInitialState());
    setStorageError(null);
    setDirty(true);
    try {
      getBrowserStorage()?.removeItem("studyquest:progress:v1");
    } catch {
      setStorageError("Não foi possível remover os dados salvos do navegador.");
    }
  }, []);

  const recoverStorage = useCallback(() => {
    setState(createInitialState());
    setStorageError(null);
    setDirty(true);
  }, []);

  const value = useMemo<StudyQuestContextValue>(
    () => ({
      state,
      storageError,
      skillStatus,
      startLesson,
      completeLessonStep,
      submitAssessment,
      completeMission,
      completeReview,
      updateGoal,
      exportBackup: () => exportBackup(state),
      importBackup: importStudentBackup,
      resetProgress,
      recoverStorage,
    }),
    [
      state,
      storageError,
      skillStatus,
      startLesson,
      completeLessonStep,
      submitAssessment,
      completeMission,
      completeReview,
      updateGoal,
      importStudentBackup,
      resetProgress,
      recoverStorage,
    ],
  );

  return (
    <StudyQuestContext.Provider value={value}>
      {children}
    </StudyQuestContext.Provider>
  );
}

export function useStudyQuest() {
  const context = useContext(StudyQuestContext);
  if (!context) {
    throw new Error("useStudyQuest precisa estar dentro de StudyQuestProvider.");
  }
  return context;
}

export type {
  AssessmentAttempt,
  AssessmentMode,
  Goal,
  ReviewEntry,
  SkillStatus,
  StudyQuestState,
};

