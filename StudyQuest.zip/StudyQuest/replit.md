# StudyQuest

Plataforma local-first de aprendizagem adaptativa para preparar estudantes universitários para Cálculo I com habilidades, avaliações, progressão e revisões espaçadas.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/studyquest run dev` — run the StudyQuest web app
- `pnpm --filter @workspace/studyquest run typecheck` — typecheck StudyQuest
- `pnpm --filter @workspace/studyquest run test` — test StudyQuest domain rules
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/studyquest/src/domain/` — learning catalog, domain rules, and browser persistence validation
- `artifacts/studyquest/src/state/` — React state provider that connects the UI to the domain rules
- `artifacts/studyquest/src/` — responsive StudyQuest interface

## Architecture decisions

- Keep progress in versioned LocalStorage for the MVP; the domain functions are isolated so a future backend can replace the persistence adapter.
- XP rewards use stable activity IDs so repeated clicks, attempts, or reloads cannot claim one-time rewards twice.
- Mastery is earned only from a scored diagnostic or mastery assessment; XP never unlocks a prerequisite.
- Reviews maintain history and do not revoke previously mastered prerequisite knowledge.
- The Cálculo I catalog is illustrative and must be checked against the target institution's syllabus.

## Product

StudyQuest helps students identify prerequisite gaps, study structured lessons, demonstrate mastery, and revisit mastered content on a spaced schedule.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
